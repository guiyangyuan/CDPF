# SDD ledger — plan: docs/plans/2026-09-13-h1-validation-prep.md

Base ce02dbe7afe1fff82c49c43528e97355bc6b3c6e; existing isolated worktree, new branch codex/h1-validation-queue. Fresh plan, no tasks completed yet.
Baseline is exact published ce02dbe product tree,153 tests passed immediately preceding turn; product hashes unchanged. No redundant baseline rerun.
User authorizes next no-GPU preparation and persistent GitHub publication. Current endpoint bjb1:42527 successfully authenticated using prior user credential (not stored); same container a03b4fb96c-09b042f2,2GiB cgroup,no devices,38GB free. BatchMode initial auth failed; subsequent password auth succeeded. SSH master /tmp/tc-h1-prep-42527.sock.
Ruling: Use existing isolated worktree with a new branch; preserve previous plan workspace and archives. Prior consent/developer authorization covers this reversible operation.
Ruling: Preserve existing model source and separate H1 Base-validation tools; no old source-check bypass. TEST.NO_TEST prevents train final test, does not change training updates.
Ruling: Freeze anchor prediction equality plus logits rtol1e-5/atol1e-4 before execution to tolerate numerical hardware roundoff without accepting unrelated results; failure stops, no tolerance adjustment.

| Task pair / task | Contract examined | Finding |
|---|---|---|
|1/2|prepared.json + build_train_command/load_prepared/load_export|Task1 defines public interfaces; Task2 consumes checked immutable artifacts|
|1/3|CPU prepare and source hash|Cache-free sampling, no CLIP construction permits2GiB server preparation|
|2/3|plan/run separation|Controller invokes plan only; explicit future GPU run separate|
|1|Source/config versus export|new current-source checkpoint only; historical data authenticators reused read-only|
|2|Budget/gates versus executor|fixed4train cap and anchor must precede candidate; no retries|
|3|Preparation versus final completion|server+local evidence required; no new model scores|

Task1 pending. Task2 pending. Task3 inventory begun; no mutation on server yet.

Task1 implementer /root/h1_prepare_export active, basee8ce5c9. Controller read-only inventory verified2516files/686637734bytes across local/server, including all2000train+500val images, metadata,3configs,3historical exports/NPZ andCLIP. Same container,noGPU. Local one-off inventory initially used systemPython without hashlib.file_digest; fixed invocation to specifiedtc-venv and context-managed hashing. No experimental input changed.

Task1 implementation a621920,15focused/168full passed. Reviewer /root/h1_prepare_review active. Controller4actual-data CPU prepares passed at a621920; independent receipt audit verified exact previous train/val hashes, all image bytes, fixed Base/val/no-auto-test and DTDpair onlymode/output; optimizer settings identical. Evidence ../../h1-prep-20260913/local-prepared-a621920 and local-preparation-audit-a621920.json. No training.

Task1 scoped review FAIL: P1 export fresh path protects prepared/model only, permits nesting into source/data inputs. Original implementer resumed for fixround1; tests must reject source/data nested paths before writes. Controller actual prepares used disjoint directories and remain valid historical evidence; new operation SHA will require new prepared outputs after fix, not silent relabeling. No other scoped findings.

Ruling: Candidate frozen M must also preserve historical argmax/allclose under the predeclared anchor tolerance. This enforces unchanged inference rather than choosing a setting; a rounding mismatch would stop execution and need a documented diagnosis, never tolerance tuning. Task2 addendum records interface and disjoint-output risks before implementation.

Task1: complete (e8ce5c9..5145115, scoped re-review PASS/PASS; P1 fixed). Latest16focused pass;168full was pre-fix, final full deferred to integration. New4case actual CPU receipts running at5145115. Task2 starts from5145115 and consumes the documented interfaces and task-2-addendum.

Task2 implementation28a84a2,21focused/190full passed; exact Fraction boundary regression covered and fixed, no threshold changes. Scoped reviewer /root/h1_queue_review pending. Controller actual local plan/no-CUDA CLI refusal verified zero subprocess commands; ready-study root remains absent. Independent historical500row arithmetic oracle matches exactly; this is software QA only, no H1 results. Controller verifier first missed source sys.path, corrected and rerun successfully; failed log retained.

Task2 scoped review FAIL, two Important findings: dynamic model/export/analysis input files absent from stage snapshots, and insufficient export/analysis binding to planned prior-stage evidence. Original implementer resumed for fix round1/5 from28a84a2. Both affect execution audit chain; future GPU queue is not ready until fixed. Minor deferred: informational dataset prints in existing full test output. No CUDA work started. Root GitHub read-only comparison confirms no integration/push this turn yet.

Task2 fix round1 implementationefcd3db: both Important bindings fixed;24focused/193full pass, scoped re-review running28a84a2..efcd3db. Root generating current-operation local plan, old28a84a2 plans preserved as superseded evidence. h1_analysis and Task1script remain unchanged; independent500row arithmeticQA/4CPUprepared receipts remain valid for those operations. No actual train.

Task2 fix round1/5:2 addressed,0 open Important;28a84a2..efcd3db, scoped re-review PASS/PASS. Task 2: complete (5145115..efcd3db, review clean on blockers). Minor deferred: execute_plan stage_validator Callable annotation still2args vs actual3args, h1_study.py:445/512; final reviewer to triage along with informational stdout. Task1 complete at5145115. Controller current local plan atlocal-plan-efcd3db passed fixed13stage/4train schedule and protected study absent; current no-CUDA CLI proof in progress. Sourcearchive packageefcd3db built but NOT deployed; final wholebranch review next.

Final wholebranch review ce02dbe..efcd3db PASS; no blockers. Reviewer independently checked exact archive/upload hashes, operational helpers,4cases and unchanged training SHA. Ruling: defer stale stage_validator type annotation because runtime/default/tests accept3args and no type checker is used; cost is future static-tool confusion, recorded in report. Informational stdout is non-failing test noise, no product scope change. Proceed to exact reviewed package CPU-only deployment. Local final plan/no-CUDA CLI guard efcd3db PASS zero trainingcommands;4prepared receipts and old500row oracle remain bound to unchanged scripts.

Task 3: server preparation and independent verification complete. Exactefcd3dbrelease deployed to fresh dirs;7commands all first-attemptsuccess,193CPUtests,4actualprepare andplanonly. Inputs2516unchanged;24serverevidencefiles downloadedSHA-checked before/afterextraction; independent2,980records check and cross-machine normalizedsample/image/configaudit PASS. Local+server final-verification.json PASS; no realtrain/CUDAexport/accuracy. Controller docs updated from evidence. Final evidence archive+authorizedGitHub publication are being finalized; code review complete and no sourcechanges afterefcd3db. No need rerun passed suites for report-only edits.
