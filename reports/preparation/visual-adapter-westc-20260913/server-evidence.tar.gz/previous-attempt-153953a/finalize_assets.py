"""Verify transferred images/CLIP, create a new seed1 cache, then release CPU preparation."""
from pathlib import Path
import hashlib
import json
import os
import sys
import tarfile

base = Path('/root/autodl-tmp/textconsistency')
source = base/'releases/visual-adapter-pilot-westc-20260913-153953a'
setup = base/'setup-logs/visual-adapter-pilot-westc-20260913-153953a'
archive = base/'inbox/fgvc-aircraft-full-images.tar.gz'
clip = base/'inbox/ViT-B-16.pt'
expected = {
    str(archive): 'baf805b7b07092f5398f306f8020dc8d4ef0df62fc7e129a0223d32a65a62ab2',
    str(clip): '5806e77cd80f8b59890b7e101eabd078d9fb84e6937f9e85e4ecb61988df416f',
}
assert not (setup/'assets-ready.json').exists()
assert not (base/'data/fgvc_aircraft').exists()
assert not (base/'assets/ViT-B-16.pt').exists()
for path, sha in expected.items():
    with open(path, 'rb') as handle:
        assert hashlib.file_digest(handle, 'sha256').hexdigest() == sha, path
with tarfile.open(archive) as tf:
    members = tf.getmembers()
    assert len(members) == 10019
    for member in members:
        path = Path(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert path.parts[0] == 'fgvc_aircraft' and 'split_fewshot' not in path.parts
    tf.extractall(base/'data', filter='data')
assert len(list((base/'data/fgvc_aircraft/images').glob('*.jpg'))) == 10000
clip.rename(base/'assets/ViT-B-16.pt')
os.chdir(source)
sys.path[:0] = [str(source), str(source/'Dassl.pytorch')]
from scripts.repro import visual_adapter_validation as v
from datasets.fgvc_aircraft import FGVCAircraft

cfg = v.case_config('simple_fusion', base/'data', base/'assets/ViT-B-16.pt', setup/'unused-cache-output', cuda=False)
v.set_random_seed(1)
dataset = FGVCAircraft(cfg)  # Dataset/cache construction only; no model or optimizer.
_, _, _, classes, _, samples = v._dataset(cfg)
cache = base/'data/fgvc_aircraft/split_fewshot/shot_16-seed_1.pkl'
cache_receipt = v.validate_fewshot_cache(cache, v.training, base/'data', samples['train'], samples['val'])
assert len(dataset.train_x) == 800 and len(dataset.val) == 200 and len(classes) == 50
receipt = {'state': 'verified', 'transferred_files_sha256': expected, 'image_count': 10000,
           'archive_members': 10019, 'cache_sha256': cache_receipt['sha256'],
           'cache_generated_from_official_splits_seed': 1, 'sample_hashes': v.SAMPLE_HASHES,
           'source_sha256': v.source_digest(), 'model_loaded': False, 'training_started': False, 'gpu_used': False}
v.atomic_json(setup/'assets-ready.json', receipt)
print(json.dumps(receipt, indent=2))
