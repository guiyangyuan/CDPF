# Task2 integration facts and boundaries

Task1 public interfaces are documented in task-1-report.md; read those API/receipt descriptions rather than re-exploring model code. It provides arrays `labels`, `S`, `T`, `M`, `ensemble` and top-level dataset_key/seed/mode/loss_identity/protocol/source identity; h1_analysis may use historical.load_export only for authenticated existing references. CLI signatures match your brief.

Controller already independently prepared four actual local cases and checked images/samples/configs; these are software-preparation evidence, not new checkpoints. Final prepared paths will be sent at dispatch after the Task1 path fix. Do not run actual-data model training or server commands.

Concrete risks to cover in your scope:
- Build/revalidate exact commands from trusted prepared receipts, not arbitrary editable argv. Plan/run separation must make CPU planning harmless and no-CUDA run refuse before spawning any training.
- Fresh study/plan/model/export outputs must be disjoint from source, data, prepared/config files and historical bundles, including resolved symlink/ancestor aliases. Only the dedicated newly reserved study tree contains stage outputs.
- Require exactly DTD/full_kl anchor then UCF101/DTD/fgvc_aircraft weighted_nckd, seed1; validate identities rather than caller labels. Do not skip/forge anchor completion or accept mixed checkpoints, duplicate cases, missing data or partial aggregates.
- Preserve all raw S/T/M/ensemble and fixed S+M, all comparisons and both positive/negative outcomes. H1 candidate scores must never be substituted by old S1 values. The controller's historical-analysis-oracle.json exercises arithmetic using old S1 only and is not a method result.
- Candidate M is the same frozen description baseline; verify its argmax and numerical agreement to each case's authenticated historical M using the already-fixed anchor tolerance, to detect an unintended inference change. This check does not select or tune a candidate; any mismatch is an integrity failure.
- Be careful with absolute paths in transform hashes: compare within-machine strict prepare/export identity; compare relative rows/classes/image bytes across machines.
- Scope is two new scripts, two tests and the usage document specified in the brief; do not edit training source, old validation tools, or controller reports.

When finished, give the exact CPU plan CLI and future run CLI, the output schemas needed for controller deployment/audit, focused/full test log paths and commits. No subagents.
