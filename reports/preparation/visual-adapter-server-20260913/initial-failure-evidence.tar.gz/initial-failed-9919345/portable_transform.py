"""Compare actual CPU validation transforms across machines using relative image IDs."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--prepared', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path[:0] = [str(args.source), str(args.source/'Dassl.pytorch')]
from scripts.repro import visual_adapter_validation as v

assert not args.output.exists()
p = v.load_prepared(args.prepared)
cfg = v.case_config('simple_fusion', p['data_root'], p['clip_path'], args.prepared.parent/'unused-model', cuda=False)
_, val, _, _, _, _ = v._dataset(cfg)
loader, _ = v.probe.build_val_loader(cfg, val)
digest = hashlib.sha256()
count = 0
for batch in loader:
    batch['impath'] = [str(Path(path).resolve().relative_to(Path(p['data_root']))) for path in batch['impath']]
    n, shape, dtype = v.probe._update_decode_digest(digest, batch)
    count += n
assert count == 200
receipt = {'kind': 'CPU validation tensors/labels/relative sample IDs', 'count': count,
           'tensor_shape': shape, 'tensor_dtype': dtype, 'portable_transform_sha256': digest.hexdigest(),
           'helper_sha256': v.sha256(__file__), 'model_loaded': False, 'gpu_used': False}
v.atomic_json(args.output, receipt)
print(json.dumps(receipt, indent=2))
