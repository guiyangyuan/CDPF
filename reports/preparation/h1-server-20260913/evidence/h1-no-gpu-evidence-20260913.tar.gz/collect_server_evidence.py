"""Read completed CPU preparation and archive only its evidence, with per-file hashes."""
from pathlib import Path
import argparse,hashlib,json,tarfile
p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);args=p.parse_args()
m=json.loads(args.manifest.read_text());prep=Path(m['preparation_dir']);ready=json.loads((prep/'ready.json').read_text())
assert ready['state']=='cpu_preparation_complete' and ready['formal_training_runs']==0 and not ready['gpu_training_started']
assert not Path(m['study_output']).exists()
inbox=args.manifest.parent;archive=inbox/'server-evidence.tar.gz';receipt=inbox/'server-evidence-receipt.json'
assert not archive.exists() and not receipt.exists()
files=[]
for path in sorted(prep.rglob('*')):
 if path.is_file():
  assert path.suffix in ('.json','.yaml','.log') and not path.is_symlink()
  files.append((path,'preparation/'+str(path.relative_to(prep))))
for name in ('manifest.json','deploy_and_prepare.py','collect_server_evidence.py','deployment.log'):
 path=inbox/name
 if path.is_file():files.append((path,'deployment/'+name))
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
rows=[{'path':name,'bytes':path.stat().st_size,'sha256':sha(path)} for path,name in files]
with tarfile.open(archive,'w:gz') as tar:
 for path,name in files:tar.add(path,arcname=name,recursive=False)
result={'state':'verified_server_evidence','commit':m['commit'],'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'files':rows,'future_study_absent':True,'formal_training_runs':0,'gpu_training_started':False}
receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
