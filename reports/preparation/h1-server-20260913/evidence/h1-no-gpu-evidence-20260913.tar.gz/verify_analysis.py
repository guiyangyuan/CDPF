"""Test pure analysis arithmetic with historical S1 arrays; create NO H1 result artifact."""
from pathlib import Path
from fractions import Fraction
import hashlib,json,subprocess,sys
import numpy as np

work=Path(__file__).resolve().parent; source=work.parent/'h1-cpu-20260912/source'
sys.path.insert(0,str(source/'scripts/repro'))
sys.path.insert(0,str(source))
import h1_analysis as analysis

oracle=json.loads((work/'historical-analysis-oracle.json').read_text())
cases=json.loads((work/'local-cases.json').read_text())[1:]
pure_reports=[]; maximum_accuracy_error=0.0; records=0
keys={'C+M_logits':'C_plus_M_logits','C+M_probability':'C_plus_M_probability','S0+M_logits':'S0_plus_M_logits'}
before={}
for case in cases:
    export=Path(case['historical_export']); npz=export.with_name('logits.npz')
    for path in (export,npz): before[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    historical=json.loads(export.read_text())
    with np.load(npz,allow_pickle=False) as raw: arrays={name:raw[name].copy() for name in raw.files}
    # In-memory test fixture only. No checkpoint/identity/export is forged or saved.
    fixture={'dataset_key':case['dataset'],'seed':1,'mode':'weighted_nckd',
             'rows':historical['rows'],'class_order':historical['class_order']}
    current={'labels':arrays['labels'],'S':arrays['S1'],'T':arrays['T1'],'M':arrays['M'],
             'ensemble':np.float32(.5)*(arrays['S1']+arrays['T1'])}
    actual=analysis.compute_candidate_analysis(fixture,current,historical,arrays)
    expected=next(row for row in oracle['rows'] if row['dataset']==case['dataset'])
    metrics={'historical_S1_plus_M':actual['current_metrics']['S+M_logits'],
             **{alias:actual['comparators'][name] for name,alias in keys.items()}}
    for name,metric in metrics.items():
        assert metric['correct']==expected['correct'][name] and metric['total']==expected['total']
        error=abs(metric['accuracy_pct']-expected['accuracy_pct'][name]); maximum_accuracy_error=max(maximum_accuracy_error,error)
        assert error<1e-12
    pure_reports.append(actual);records+=len(arrays['labels'])
aggregate=analysis.aggregate_candidates(pure_reports)
expected_guards={}
for name,alias in keys.items():
    deltas=[100*Fraction(row['correct']['historical_S1_plus_M']-row['correct'][alias],row['total']) for row in oracle['rows']]
    delta=sum(deltas,Fraction())/3
    expected_guards['vs_'+name]=(delta>0 if name=='S0+M_logits' else delta>=0 and min(deltas)>=-1)
    assert abs(aggregate['deltas_pp']['vs_'+name]['macro']-float(delta))<1e-12
assert all(aggregate['guards'][key]==value for key,value in expected_guards.items())
assert aggregate['guards']['all_passed']==all(expected_guards.values())
for name,digest in before.items(): assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
result={'state':'passed','purpose':'Pure arithmetic QA with authenticated OLD S1 arrays, not H1 trained-model results',
    'implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),
    'cases':3,'records':records,'all_counts_exact':True,'max_accuracy_error':maximum_accuracy_error,
    'guards_match_independent_fraction_oracle':True,'historical_inputs_unchanged':True,
    'new_accuracy_claim':False,'formal_training_runs':0,'gpu_training_started':False}
output=work/'analysis-verification.json'
if output.exists():raise FileExistsError(output)
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
