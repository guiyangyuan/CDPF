from pathlib import Path
import hashlib,json,os,subprocess
w=Path(__file__).resolve().parent;s=w.parent/'h1-cpu-20260912/source';python=w.parent/'tc-venv/bin/python'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip();label=commit[:7]
plan=w/('local-plan-'+label);study=w/('local-study-'+label+'-never-run')
env=dict(os.environ,PYTHONPATH=str(s)+':'+str(s/'Dassl.pytorch')+':'+str(s/'tests'),OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='')
keys=['anchor-dtd','candidate-ucf101','candidate-dtd','candidate-fgvc_aircraft']
command=[str(python),str(s/'scripts/repro/h1_study.py'),'plan','--prepared',*[str(w/'local-prepared-5145115'/k/'prepared.json') for k in keys],'--output-root',str(study),'--output-dir',str(plan)]
assert not plan.exists() and not study.exists()
with (w/('local-plan-'+label+'.log')).open('w') as log:subprocess.run(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
p=json.loads((plan/'plan.json').read_text());assert p['state']=='planned_not_executed' and not study.exists()
kinds=[x['kind'] for x in p['stages']];expected=['train','export','anchor_audit']+['train','export','candidate_analysis']*3+['aggregate'];assert kinds==expected,kinds
assert len(p['cases'])==4 and kinds.count('train')==4 and len(kinds)==13
for x in p['operations'].values():assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256']
result={'state':'passed','implementation_commit':commit,'plan':str(plan/'plan.json'),'plan_identity_sha256':p['plan_identity_sha256'],'file_sha256':hashlib.sha256((plan/'plan.json').read_bytes()).hexdigest(),'stages':13,'future_training_cap':4,'study_absent':True,'formal_training_runs':0,'gpu_training_started':False}
(w/('local-plan-verification-'+label+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
