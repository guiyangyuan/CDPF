from pathlib import Path
import datetime,json,subprocess
launch=Path('/root/autodl-tmp/textconsistency/setup-logs/h1-gpu-start-20260913-efcd3db');record=json.loads((launch/'start-record.json').read_text());root=Path(record['study_output']);plan=json.loads(Path(record['plan']).read_text());stat=Path('/proc/'+str(record['pid'])+'/stat')
alive=False
if stat.exists():
 fields=stat.read_text().rsplit(')',1)[1].split();alive=fields[19]==record['proc_start_ticks'] and fields[0]!='Z'
status=json.loads((root/'status.json').read_text()) if (root/'status.json').exists() else {'state':'validating_plan','commands':[]}
r={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runner_alive':alive,'pid':record['pid'],'state':status['state'],'completed_stages':status['commands'],'error':status.get('error'),'current_stage':plan['stages'][len(status['commands'])]['stage_id'] if status['state'] in ('running','validating_plan') and len(status['commands'])<13 else None,'train_tails':{}}
for stage in plan['stages']:
 if stage['kind']=='train':
  for p in Path(stage['output_dir']).glob('log*txt'):
   r['train_tails'][stage['case_id']]=p.read_text(errors='replace').splitlines()[-3:]
r['analysis_summary']={}
passed={x['stage_id'] for x in status['commands'] if x['status']=='passed'}
for stage in plan['stages']:
 if stage['kind'] in ('anchor_audit','candidate_analysis','aggregate') and Path(stage['result_path']).is_file():
  a=json.loads(Path(stage['result_path']).read_text());summary={'status':a['status'],'validated_by_queue':stage['stage_id'] in passed}
  if 'current_metrics' in a:summary['candidate_accuracy_pct']=a['current_metrics']['S+M_logits']['accuracy_pct'];summary['comparators']={k:v['accuracy_pct'] for k,v in a['comparators'].items()}
  if 'guards' in a:summary['guards']=a['guards']
  r['analysis_summary'][stage['case_id']]=summary
r['runner_tail']=(launch/'runner.log').read_text(errors='replace').splitlines()[-8:]
r['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=utilization.gpu,memory.used','--format=csv,noheader'],text=True).strip()
print(json.dumps(r,indent=2))
