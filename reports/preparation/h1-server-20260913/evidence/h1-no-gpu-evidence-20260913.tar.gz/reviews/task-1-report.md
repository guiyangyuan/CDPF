# Task 1 report: authenticated H1 prepare and export

Status: DONE

Commit: `a621920` (`feat: add authenticated H1 validation export`)

Owned files committed:

- `scripts/repro/h1_validation.py`
- `tests/repro/test_h1_validation.py`

No model, trainer, dataset, historical validation tool, documentation, or controller file was changed by Task 1.

## Public interfaces for Task 2

```python
from pathlib import Path
from scripts.repro.h1_validation import build_train_command, load_export, load_prepared

prepared = load_prepared(Path("/absolute/prepared-dir/prepared.json"))
argv = build_train_command(
    prepared,
    Path("/absolute/fresh-model-dir"),
    python="/absolute/python",
)
receipt, arrays = load_export(Path("/absolute/export-dir/export.json"))
```

`build_train_command(prepared, model_dir, python=sys.executable)` returns:

```text
[python, <current-source>/train.py,
 --root, <prepared-data-root>,
 --output-dir, <fresh-model-dir>,
 --seed, 1,
 --config-file, <prepared-dir>/future_config.yaml]
```

It rejects a pre-existing model directory and never invokes `run_pilot.py`.

`load_prepared(path)` revalidates the fixed inventory/reference, exact seed-1 historical export and NPZ, authenticated historical kd1 config, current source SHA, CLIP/template/metadata hashes, cache-free samples, existing few-shot cache order, train/val image bytes and decodability, saved future config, val transform, and operation-tool hashes. It returns the prepared dictionary.

`load_export(path)` calls `load_prepared`, revalidates the complete epoch-20 model bundle, checks the NPZ schema/dtypes/shapes/finiteness, exact rows/labels/classes/order, fixed `ensemble = .5 * (S + T)`, transform evidence, mode/source/checkpoint bindings, and returns `(receipt, arrays)`. Array keys are exactly `labels`, `S`, `T`, `M`, and `ensemble`.

Prepare CLI:

```text
python scripts/repro/h1_validation.py prepare \
  --source-root SOURCE \
  --data-root DATA \
  --historical-export HISTORICAL_EXPORT_JSON \
  --historical-config HISTORICAL_KD1_EFFECTIVE_CONFIG_YAML \
  --dataset {ucf101,dtd,fgvc_aircraft} \
  --mode {full_kl,weighted_nckd} \
  --output-dir FRESH_PREPARED_DIR
```

This writes `prepared.json` and `future_config.yaml`. Prepare is CPU-only and performs no model, optimizer, CUDA, training, or test inference. It preserves the historical training settings and changes only root/output paths, fixed evaluation controls, and the requested KD loss mode. It requires an existing `shot_16-seed_1.pkl` whose Base train/val rows exactly match the cache-free reconstruction.

Export CLI:

```text
python scripts/repro/h1_validation.py export \
  --prepared PREPARED_JSON \
  --model-dir COMPLETE_EPOCH20_MODEL_DIR \
  --output-dir FRESH_EXPORT_DIR
```

Export rejects no-CUDA hosts before loading the prepared receipt or model. It constructs one current `CustomCLIP`, strictly loads every prompt/aggregator tensor, exports Base-val `S`, `T`, normalized masked-description mean `M`, and the original alpha-.5 ensemble, then writes `export.json` and `logits.npz`.

## Validation evidence

- Focused final: 15/15 passed. Log: `../../h1-prep-20260913/task1-final-focused.log`.
- Full final suite: 168/168 passed. Log: `../../h1-prep-20260913/task1-final-full-suite.log`.
- All three authenticated historical configs passed current `setup_cfg`/`check_cfg` for both modes; only allowed path/evaluation/mode fields differed. Log: `../../h1-prep-20260913/task1-config-smoke-2.log`.
- Current model-source digest remained `387ea6e46aa0fa6cba5109e64baab94a548b35c200a1945267d392bc35a36677`.
- Python compilation and staged whitespace checks passed before commit.

RED evidence began with the missing module import (`task1-red-01.log`) and missing public behavior (`task1-red-02.log`). Intermediate failures were limited to incomplete synthetic test fixtures (transform evidence and macOS resolved temporary paths) and one checkpoint fixture path normalization; each was corrected before the final focused and full runs.

## Remaining operational boundary

Task 1 used synthetic data and the existing real tiny-CLIP/optimizer fixture only. Actual dataset preparation, cross-machine receipt comparison, server deployment, and any future CUDA training/export remain controller work. Decoded transform hashes intentionally bind to paths on the machine that prepared the receipt; cross-machine comparison should use relative sample rows and image-content hashes, while each machine enforces its own prepare-to-export transform digest.

## P1 review fix: immutable export inputs

Review-fix commit: `5145115` (`fix: protect H1 export input roots`).

The finding in `task-1-review.md` was fixed by authenticating the raw prepared receipt before creating the export directory and rejecting any output that overlaps an immutable input. Protected inputs include the prepared JSON and artifact directory, model directory, source and data roots, fixed inventory/reference files, future and historical configs, historical export/NPZ, CLIP/template assets, few-shot cache, and source metadata files. The overlap check is repeated against the strictly loaded prepared receipt before checkpoint or model work.

The existing fresh-output contract remains unchanged: export still requires a path that does not exist. The no-CUDA failure receipt remains supported for a valid disjoint output directory.

RED command:

```text
PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python -m unittest tests.repro.test_h1_validation.ExportContracts.test_export_rejects_fresh_output_nested_in_source_or_data_before_any_write -v
```

Both source-root and data-root cases failed by reaching the patched `load_prepared` after creating the output, demonstrating the reported defect. Log: `../../h1-prep-20260913/task1-p1-red.log`.

Targeted GREEN command added the existing no-CUDA failure-receipt contract:

```text
PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python -m unittest tests.repro.test_h1_validation.ExportContracts.test_export_rejects_fresh_output_nested_in_source_or_data_before_any_write tests.repro.test_h1_validation.ExportContracts.test_cuda_cli_guard_records_failure_without_loading_prepared_or_model -v
```

Result: 2/2 passed. Log: `../../h1-prep-20260913/task1-p1-green-targeted.log`.

Focused verification command:

```text
PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python -m unittest tests.repro.test_h1_validation -v
```

Result: 16/16 passed in 3.911 seconds. Log: `../../h1-prep-20260913/task1-p1-focused.log`. The full 168-test suite passed before the review fix at `a621920`; per controller direction it was not rerun here and will be run by the final integration controller.
