# SDD ledger — plan: docs/plans/2026-09-12-h1-cpu.md

Spec: reports/diagnostics/kd-failure-20260912/NEXT_STEP.md, user approved CPU implementation.
Base commit: 594510238b6632f82721cf47d0d1e14dc61fc819.
Branch: codex/h1-weighted-nckd, isolated worktree in work/h1-cpu-20260912/source.
Ruling: create isolated workspace and later push without repeated permission — task authorization and developer autonomy cover reversible isolation and persistent GitHub publication consent.
Ruling: use bash with explicit brief output because packaged helper scripts lack execute permission; do not change installed skills.

| Task pair / task | Contract reviewed | Finding |
|---|---|---|
| 1 / 2 | training_losses keyword-only kd_loss_mode values full_kl, weighted_nckd | Runtime must pass exact string and validate before assets; coherent |
| 1 / 2 | shared common.py ownership | Task1 only loss, task2 checkpoint loader; sequential implementers |
| 2 / 3 | artifact identity | Preserve source checks and test all new fields; no old-checkpoint bypass |
| 1 | loss definition vs tests | weighted term only, class count 2 zero valid, count 1 invalid; coherent |
| 2 | configuration vs old pilot | Direct train.py only; old pilot still full-KL and Novel pipeline not reused; coherent |
| 3 | CPU verification vs no training | Tiny synthetic optimizer steps are correctness tests, not formal experiments; distinguish in report |

Task 1: pending baseline. Initial baseline calls had missing Dassl PYTHONPATH then wrong unittest package discovery; saved both errors, no source changes.
Task 2: pending.
Task 3: pending.

Baseline: complete, 128 tests passed (7.239 s) with correct PYTHONPATH and package discovery; logs ../baseline-tests-final.log. Task 1 implementer /root/h1_loss active. Controller preparing independent authenticated real-logit chain/default verification outside the product tree; no model/optimizer calls.

Task 1 implementation committed 302aeaf. Red/green evidence retained; 138/138 suite passed. Core worker corrected invalid label dtype and empty batch after controller review, covered by malformed-input cases. Task review pending.
Task 1: complete — 302aeaf, task review approved (no important issues). Task 2 base: 302aeaf. Mode API is keyword-only, no shared mode validator exposed. Integration addendum records unsupported-trainer and legacy identity rules.

Task 2 implementation: c59f0c3. Focused 28/28 and full suite148/148 passed; RED12 failures/2 errors retained. Runtime exposes versioned loss_identity in signature/provenance; default legacy audit full_kl. Task review pending.
Controller independent checks: 36 default full-KL exact loss/gradient comparisons on real logits, 18 weighted chain checks passed (max value2.22e-16, gradient6.94e-18), no optimizer/model load. six configs across3datasets differ only KD_LOSS_MODE. No new scores.

2026-09-13 resume after user interruption: no pending shell sessions, branch still c59f0c3; Task2 worker interrupted before fix edits and resumed. Task2 review REQUEST_CHANGES: H-001 sparse protocol/read_metric bypass lets explicit weighted mode avoid identity checks; also early NaN loss scalars not rejected. Fix round1 is with original implementer /root/h1_integration. Do not redispatch completed Task1 or re-run old GPU jobs. Publish is pending all fixes/reviews/verification.

Task2 fix round1 committed63ba4cf: closes sparse protocol/direct metric mode bypass and rejects non-finite loss configuration early. RED29 tests/10 failures; GREEN29 focused and152 full tests passed. Scoped re-review pending. Controller minor cleanup removes unused test import only.

Task2 scoped re-review approved fix1. Final whole-branch review found remaining medium sparse-modern-full-KL scalar inconsistency: protocolT2 / manifestT9 / configT7 / metricsT2 can aggregate if kd_weight omitted. Original implementer resumed for final fix. Ruling: modern identity must have sufficient expected weight/temp context and agree across artifacts; keep only truly legacy absence under sparse full-KL. Preserve previous final152-test verification as before-final-fix snapshots, do not overwrite. No loss-core changes required; real-logit numeric checks remain valid with final function SHA equality.

Final fix committedce6e7ee. Modern identity or explicit mode marker now requires expected KD weight and temperature; only wholly absent modern markers qualify for sparse legacy full-KL compatibility. Exact M-001 reproducer and partially stripped modern artifacts reject. Focused18/18, full153/153 pass; final scoped re-review pending.

Final scoped re-review: APPROVE, M-001 resolved; 3 targeted tests and diff check passed. Task2 complete at ce6e7ee. Controller final complete suite153/153 in8.507s; final-verification.json binds the unchanged loss core, authenticated old inputs, 6 config checks, training source and audit file hashes to ce6e7ee. Task3 CPU validation complete; publication pending. No server/GPU/formal experiment runs. Archive is prepared before publication; final publication receipt will be saved outside the immutable evidence archive. Worktree retained for reproducibility because verification scripts resolve this source path.
