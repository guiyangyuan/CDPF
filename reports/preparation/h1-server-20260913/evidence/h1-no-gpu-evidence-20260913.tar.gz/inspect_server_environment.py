from pathlib import Path
import datetime,json,platform,shutil,subprocess
import numpy,PIL,torch,torchvision
r={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hostname':platform.node(),'python':platform.python_version(),'torch':torch.__version__,'torchvision':torchvision.__version__,'numpy':numpy.__version__,'pillow':PIL.__version__,'cuda_available':torch.cuda.is_available(),'torch_cuda':torch.version.cuda,'cgroup_memory_max':Path('/sys/fs/cgroup/memory.max').read_text().strip(),'data_disk':dict(zip(('total','used','free'),shutil.disk_usage('/root/autodl-tmp')))}
p=subprocess.run(['nvidia-smi','-L'],capture_output=True,text=True);r['nvidia_smi']={'returncode':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}
print(json.dumps(r,indent=2))
