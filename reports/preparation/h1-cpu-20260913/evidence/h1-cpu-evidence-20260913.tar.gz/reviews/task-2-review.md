# Task 2 review

## Verdict

**REQUEST_CHANGES.** Runtime/checkpoint integration is substantially compliant, but the audit does not fail closed for sparse protocols and can authenticate legacy full-KL metrics as an explicitly weighted control.

## Findings

### H-001 — Sparse audit protocols bypass all loss-identity validation (HIGH, high confidence)

- `scripts/repro/summarize.py:136-138` checks metric identity only when both `kd_weight` and `fixed_settings` are present.
- `scripts/repro/summarize.py:207-217` checks manifest identity and effective configs only when `kd_weight` is present.
- Consequently, `scripts/repro/summarize.py:162` accepts an explicit `kd_loss_mode: weighted_nckd`, but omission of `kd_weight`/`fixed_settings` skips every new identity gate. A focused reproduction using the existing sparse legacy fixture shape, explicit `weighted_nckd`, and metrics with no identity returned a successful aggregate row.
- Impact: historical full-KL evidence can be relabelled as weighted NCKD, contradicting the required weighted fail-closed audit and the rule that legacy absence means full KL only.
- Repair: validate `kd_loss_mode` immediately after reading the protocol; permit missing identity only when the protocol resolves to `full_kl`; require the fields needed to construct the expected identity for explicit weighted protocols, then validate identity in every metric, manifest, model signature, and effective config. Add sparse-protocol regression cases for explicit weighted, unknown mode, and default/full-KL records carrying weighted identity.

## Minor note

- `trainers/textconsistency_runtime.py:69-70` does not reject non-finite scalars (`KD_TEMP=NaN` passes `check_cfg`; the same applies to some NaN loss weights because `min(...) < 0` is false). `training_losses` later rejects them at `trainers/textconsistency_common.py:323-326`, but only after asset/model setup and provenance writing at `trainers/textconsistency_runtime.py:77-134`. Use explicit `math.isfinite` checks in `check_cfg` so invalid loss identity cannot reach asset loading or produce a manifest containing `NaN`.

## Compliance and quality

- **Mode/config integration: compliant.** Historical default is declared at `train.py:124`; non-default modes for unsupported trainers are rejected before trainer construction at `train.py:166-174`; supported modes are validated before model/data construction through the trainer initialization order and `trainers/textconsistency_runtime.py:59-73`; training passes the exact mode at `trainers/textconsistency_runtime.py:142-149`.
- **Identity preservation: compliant.** The versioned identity includes mode, temperature, effective coefficient, active state, and weighting definition at `trainers/textconsistency_runtime.py:18-32`; it is copied into the model signature and run provenance at `trainers/textconsistency_runtime.py:103-123`, then preserved in checkpoints at `trainers/textconsistency_runtime.py:158-166` and metrics at `trainers/textconsistency_runtime.py:173-192`.
- **Checkpoint pre-mutation rejection: compliant for all three validated trainers.** Exact signature and top-level provenance checks occur at `trainers/textconsistency_common.py:93-107`, before tensor compatibility checks and `load_state_dict` at `trainers/textconsistency_common.py:108-118`. The strict `code_sha256` comparison remains intact at `trainers/textconsistency_common.py:100-102`.
- **Baseline/teacher behavior: compliant.** Effective KD weight is derived without disabling adaptive CE at `trainers/textconsistency_runtime.py:94-103`; teacher CE remains independent of KD mode at `trainers/textconsistency_common.py:338-365`; an inactive weighted teacherless baseline is represented with effective weight zero rather than as an active control.
- **Tests:** implementation report records 28 focused and 148 full tests passing; the root additionally reports six configuration and real-logit checks passing. This review did not repeat those suites. Focused probes confirmed H-001 and the non-finite validation note.

