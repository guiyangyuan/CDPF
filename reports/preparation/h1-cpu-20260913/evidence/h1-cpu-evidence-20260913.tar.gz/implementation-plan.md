# H1 weighted non-target KD: CPU implementation

Spec: reports/diagnostics/kd-failure-20260912/NEXT_STEP.md and the user's approval to implement CPU preparation. Preserve original full-KL defaults, architecture, descriptions, online teacher CE and inference. No server connection, GPU execution, formal experiment, paper edit, hyperparameter search or claimed accuracy improvement. GitHub publication is already authorized.

## Task 1: Implement the single weighted non-target loss

Ownership: trainers/textconsistency_common.py (training_losses and any loss-local helper only) and a new tests/repro/test_kd_losses.py. Do not edit checkpoint loading or other files owned by task 2.

Add keyword-only kd_loss_mode='full_kl' to training_losses after existing contrastive_weight positional argument. The only other allowed value is 'weighted_nckd'. Keep the historical full-KL expression and operation order for valid default calls exactly unchanged. New mode is batch mean of (1-q_y)*T^2*KL(q_non_target||p_non_target), teacher q and weight detached, with the true class removed before conditional softmax. Compute teacher non-target mass stably, e.g. sum the non-target probabilities rather than subtract a rounded q_y from one. Do not add unweighted NCKD, DKD alpha/beta knobs, gates or logit normalization. Keep student CE, online teacher CE and negative entropy unchanged.

Reject unknown mode even with KD disabled, nonfinite/nonpositive temperature and invalid weights, and malformed active weighted-KD input (teacher absent, incompatible shape, fewer than two classes, invalid labels). Two-class weighted NCKD is correctly zero because there is one non-target class; this is supported. Preserve ordinary teacher-less baseline behavior in full_kl mode.

TDD: new tests must first fail due to missing behavior. Derive expectations independently using full KL minus its binary target/non-target KL, including value AND student gradient; check true-class KD gradient zero, teacher KD gradients absent but teacher CE gradients intact, non-target normalization, class permutation/batch-mean weighting, finite extreme-logit behavior, two-class zero, KD=0 behavior and invalid options. Compare default full KL and explicit full_kl values/gradients with frozen historical formula at exact equality. Preserve RED/GREEN command/output evidence outside tracked product files.

Use /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python, OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1. Tests under tests/repro use unittest discovery. No new dependencies. Commit only owned files, report exact commands, failures and passes. No subagents.

## Task 2: Wire mode into training, checkpoint identity and audit

Ownership: train.py, trainers/textconsistency_runtime.py, checkpoint loader portion of trainers/textconsistency_common.py, scripts/repro/summarize.py, integration/audit tests. Add configuration TRAINER.TEXTCONSISTENCY.KD_LOSS_MODE default 'full_kl'. Runtime passes it to training_losses and records the declared mode, effective KD coefficient, temperature and weighting definition in run manifest, checkpoints and evaluation metrics. Same model shapes must not allow loading or relabelling a different loss mode; mismatches must reject before parameters mutate. Keep existing source SHA checks; do not bypass legacy provenance. Existing old weights remain with their frozen source snapshots.

Audits must reject weighted_nckd when historical/default full-KL is expected, including mismatched config, manifest and metrics. Missing mode is accepted only as the historical full-KL meaning when auditing legacy records; it must never be accepted as weighted_nckd. Do not make a generalized new GPU run queue or add the mode to the old run_pilot that automatically evaluates Novel. Direct train.py config is sufficient for CPU integration; later GPU orchestration is a separate bounded preparation step.

TDD integration: actual tiny CLIP model and real trainer/loss/optimizer (external pretrained weight loading may use existing tiny architecture fixture), one CPU update, frozen CLIP unchanged, online teacher updated through CE, correct loss selected, full and weighted checkpoints roundtrip all branches, changing/removing identity rejected, unknown mode rejected before asset load. Metadata must distinguish modes and temperature. Audit tests must reject deliberate mismatches and continue accepting legacy full-KL fixtures. No source-text tests.

## Task 3: Verify and publish CPU preparation

Controller responsibility: independently review task changes; run complete existing plus new tests once after integration, plus meaningful checks on saved real nine-case logits and frozen loss formula without model training. Verify weighted loss value/gradient against the independent chain decomposition and default full-KL behavior unchanged. Archive all logs and failures honestly, record exact code hash and scope. Update PROJECT_STATUS.md, dated CPU preparation report, link historical proposed plan to actual implementation status without changing historical experiment values. Do not mark GPU or algorithm validation complete. Commit, integrate verified branch and push to the user's repository; verify remote commit equality. Keep a restoration note outside the repository.
