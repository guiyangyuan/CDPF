"""Freeze already-observed Base-validation controls; this starts no experiment."""
from pathlib import Path
import csv,hashlib,json
import numpy as np
work=Path(__file__).resolve().parent; root=work.parents[1]; repo=work/'source'
table=repo/'reports/experiments/validation-probe-20260912-42527/all-methods-by-seed.csv'
rows=list(csv.DictReader(table.open()))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
soft=lambda x: np.exp(x-x.max(1,keepdims=True))/np.exp(x-x.max(1,keepdims=True)).sum(1,keepdims=True)
cases=[]
for dataset in ('ucf101','dtd','fgvc_aircraft'):
 folder=root/f'work/validation-gpu-20260912-42527/unpacked/validation-probe-20260911-v1/exports/{dataset}-seed1'
 meta=json.loads((folder/'export.json').read_text()); assert sha(folder/'logits.npz')==meta['npz_sha256']
 with np.load(folder/'logits.npz',allow_pickle=False) as a:
  C,M,S0=(a[k].astype(np.float64) for k in ('C','M','S0'))
  scores={'C+M_logits':(C+M)*.5,'C+M_probability':(soft(C)+soft(M))*.5,'S0+M_logits':(S0+M)*.5}
  comparisons=[]
  for method,score in scores.items():
   row=next(r for r in rows if r['dataset']==dataset and int(r['seed'])==1 and r['method']==method)
   correct=int((score.argmax(1)==a['labels']).sum()); assert correct==int(row['correct']) and len(a['labels'])==int(row['total'])
   assert abs(100.*correct/len(a['labels'])-float(row['accuracy_pct']))<1e-12
   comparisons.append({'method':method,'correct':correct,'total':len(a['labels']),'accuracy_pct':float(row['accuracy_pct'])})
  cases.append({'dataset':dataset,'seed':1,'controls':comparisons,
                'historical_export_sha256':sha(folder/'export.json'),'historical_logits_sha256':meta['npz_sha256']})
result={'purpose':'Existing historical Base-validation references for proposed bounded H1 pilot',
 'state':'reference_snapshot_only_not_executed','created_date':'2026-09-13','candidate':'SN+M_logits','alpha':.5,
 'shots':16,'epochs':20,'seed':1,'kd_loss_mode':'weighted_nckd','temperature':2.,'kd_weight':1.,
 'source_table_sha256':sha(table),'cases':cases,
 'guards':{'versus_each_C_plus_M':{'macro_delta_pp_at_least':0.,'per_dataset_delta_pp_at_least':-1.},
           'versus_S0_plus_M_logits':{'macro_delta_pp_strictly_greater_than':0.},
           'aggregation':'equal weight across the three datasets, not by image count'},
 'proposed_max_new_training_runs':4,'gpu_queue_created':False,'formal_training_started':False,
 'limitations':['These datasets have already been used for method decisions','Passing is not proof of novelty or independent confirmation','No new candidate scores exist']}
p=repo/'reports/preparation/h1-cpu-20260913/reference-snapshot.json'
if p.exists(): raise FileExistsError(p)
p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'state':'passed','historical_controls_checked':9,'gpu_queue_created':False,'cases':cases},indent=2))
