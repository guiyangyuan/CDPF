# Task 1 review: weighted non-target KD loss

## Spec compliance

The implementation complies with the brief. `training_losses` adds the keyword-only mode with the required default and rejects unknown modes and invalid scalar options eagerly (`trainers/textconsistency_common.py:318-328`). The active weighted path validates teacher presence, compatible two-dimensional shapes, at least two classes, nonempty batches, and valid labels (`trainers/textconsistency_common.py:329-337`). Teacher-less behavior remains available when KD is disabled.

The weighted loss is the requested batch mean of `(1-q_y) * T^2 * KL(q_non_target || p_non_target)`: the target is removed before both conditional softmaxes, teacher logits are detached, and the detached non-target mass is computed by summing full-softmax non-target probabilities (`trainers/textconsistency_common.py:346-355`). This also makes the target-logit KD gradient exactly zero and gives the required exact-zero two-class case. Student CE, online-teacher CE, and negative entropy retain their prior forms (`trainers/textconsistency_common.py:338-340,358-365`). The default full-KL expression and its operation order are unchanged (`trainers/textconsistency_common.py:342-344`).

## Findings

No important issues found.

Minor: `math` is imported but unused in the new test module (`tests/repro/test_kd_losses.py:1`). This has no behavioral effect.

The tests are meaningful and cover the central identity with an independently expressed full-KL-minus-binary-KL value and student gradient oracle (`tests/repro/test_kd_losses.py:16-25,53-64`), exact historical default value/gradient equality (`tests/repro/test_kd_losses.py:37-51`), teacher detachment versus retained teacher-CE gradients, normalization, permutation and batch weighting, extreme logits, two classes, disabled KD, and malformed inputs. I relied on the supplied evidence of 10 focused and 138 full-suite passing tests and did not rerun either suite as requested.

## Verdict

Approve.
