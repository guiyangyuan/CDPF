"""Back up a terminal fixed study, including every checkpoint and raw output."""
from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
base=Path('/root/autodl-tmp/textconsistency');study=base/'runs/h1-validation-20260913-efcd3db';prep=base/'setup-logs/h1-validation-20260913-efcd3db';launch=base/'setup-logs/h1-gpu-start-20260913-efcd3db';status=json.loads((study/'status.json').read_text());record=json.loads((launch/'start-record.json').read_text())
assert status['state'] in ('passed','stopped','failed'),'Study not terminal'
stat=Path('/proc/'+str(record['pid'])+'/stat')
if stat.exists():
 f=stat.read_text().rsplit(')',1)[1].split();assert f[19]!=record['proc_start_ticks'] or f[0]=='Z','Original runner remains alive'
assert not study.with_name(study.name+'.lock').exists(),'Study lock still present'
archive=base/'backups/h1-validation-20260913-42527.tar.gz';receipt=archive.with_name('h1-validation-20260913-42527-receipt.json')
assert not archive.exists() and not receipt.exists(),'Refusing to overwrite backup'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
files=[]
for root,prefix in ((study,'study'),(prep,'preparation'),(launch,'launch')):
 for p in sorted(root.rglob('*')):
  if p.is_file():
   assert not p.is_symlink(),'Unexpected symlink in results'
   files.append((p,prefix+'/'+str(p.relative_to(root))))
rows=[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p)} for p,name in files]
with tarfile.open(archive,'x:gz') as tar:
 for p,name in files:tar.add(p,arcname=name,recursive=False)
for (p,name),r in zip(files,rows):assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes'],'Result changed during backup'
result={'state':'complete_backup','time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'study_state':status['state'],'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':rows,'checkpoint_files':[r['path'] for r in rows if r['path'].endswith('.pth.tar-20')],'plan_sha256':sha(prep/'future-plan/plan.json'),'source_code_commit':'efcd3dbb7d5515dde3a708d4093bc503f66eba0b','study_immutable_during_backup':True,'no_retry':True,'gpu_after':subprocess.check_output(['nvidia-smi','--query-gpu=utilization.gpu,memory.used','--format=csv,noheader'],text=True).strip(),'compute_processes_after':subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'],text=True).strip()}
receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
