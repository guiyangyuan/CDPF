"""One-shot no-GPU deployment and preparation; never invoke the study run CLI."""
from pathlib import Path
import argparse,hashlib,json,os,platform,subprocess,sys,tarfile,time

def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()

def write(path,value):
    target=Path(path); temp=target.with_name(target.name+'.tmp')
    temp.write_text(json.dumps(value,indent=2)+'\n'); temp.replace(target)

def inventory(expected):
    rows=[]
    for item in expected:
        path=Path(item['remote']); size=path.stat().st_size; digest=sha(path)
        if size!=item['bytes'] or digest!=item['sha256']:
            raise ValueError('Historical input changed: '+str(path))
        rows.append({'path':str(path),'bytes':size,'sha256':digest})
    return rows

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--manifest',required=True,type=Path)
    args=parser.parse_args(); manifest=json.loads(args.manifest.read_text())
    source=Path(manifest['release_dir']); prep=Path(manifest['preparation_dir']); study=Path(manifest['study_output'])
    base=Path('/root/autodl-tmp/textconsistency')
    for path,parent in ((source,base/'releases'),(prep,base/'setup-logs'),(study,base/'runs')):
        if path.resolve().parent!=parent.resolve():
            raise ValueError('Deployment output is outside the authorized directory family: '+str(path))
    if Path(manifest['data_root']).resolve()!=(base/'data').resolve():
        raise ValueError('Unexpected dataset root')
    if Path(manifest['python']).absolute()!=(base/'.venv/bin/python').absolute():
        raise ValueError('Unexpected interpreter')
    package=args.manifest.parent/manifest['archive']
    if sha(package)!=manifest['archive_sha256']: raise ValueError('Source archive SHA mismatch')
    for path in (source,prep,study):
        if path.exists(): raise FileExistsError('Refusing existing output: '+str(path))
    prep.mkdir(parents=True); status={'state':'preparing','commit':manifest['commit'],'commands':[],
        'gpu_training_started':False,'formal_training_runs':0,'started_at':time.time()}
    write(prep/'status.json',status)
    env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',
        PYTHONPATH=str(source)+':'+str(source/'Dassl.pytorch')+':'+str(source/'tests'),
        CUDA_VISIBLE_DEVICES='',MALLOC_ARENA_MAX='2',MALLOC_TRIM_THRESHOLD_='131072')
    python=manifest['python']
    def run(command,label):
        log=prep/(label+'.log'); started=time.time()
        with log.open('w') as output:
            proc=subprocess.run(command,cwd=source,env=env,stdout=output,stderr=subprocess.STDOUT)
        row={'label':label,'command':command,'returncode':proc.returncode,'seconds':time.time()-started,
            'log':str(log),'log_sha256':sha(log)}
        status['commands'].append(row); write(prep/'status.json',status)
        print(json.dumps({'label':label,'returncode':proc.returncode,'seconds':row['seconds']}),flush=True)
        if proc.returncode: raise RuntimeError('Preparation failed: '+label)
    try:
        before=inventory(manifest['expected_inputs']); write(prep/'inputs-before.json',before)
        source.mkdir(parents=True)
        with tarfile.open(package,'r:gz') as archive:
            archive.extractall(source,filter='data')
        clip=source/'clip/ViT-B-16.pt'
        if clip.exists() or clip.is_symlink(): raise FileExistsError(str(clip))
        clip.symlink_to(manifest['clip_path'])
        for name,digest in manifest['operation_sha256'].items():
            if sha(source/name)!=digest: raise ValueError('Deployed operation SHA mismatch: '+name)
        run([python,'-c','import json,platform,torch; print(json.dumps({"python":platform.python_version(),"torch":torch.__version__,"cuda_available":torch.cuda.is_available()})); assert not torch.cuda.is_available()'],'masked-cpu-environment')
        run([python,'-m','unittest','discover','-s','tests','-v'],'full-tests')
        prepared=[]
        for case in manifest['cases']:
            out=prep/case['key']
            command=[python,str(source/'scripts/repro/h1_validation.py'),'prepare',
                '--source-root',str(source),'--data-root',manifest['data_root'],
                '--historical-export',case['historical_export'],
                '--historical-config',case['historical_config'],
                '--dataset',case['dataset'],'--mode',case['mode'],'--output-dir',str(out)]
            run(command,'prepare-'+case['key']); receipt=out/'prepared.json'
            if not receipt.is_file(): raise FileNotFoundError(str(receipt))
            prepared.append(receipt)
        plan_dir=prep/'future-plan'
        run([python,str(source/'scripts/repro/h1_study.py'),'plan','--prepared',*[str(p) for p in prepared],
             '--output-root',str(study),'--output-dir',str(plan_dir)],'plan-only')
        if study.exists(): raise RuntimeError('Plan created real study output')
        after=inventory(manifest['expected_inputs']); write(prep/'inputs-after.json',after)
        if before!=after: raise ValueError('Inputs changed during CPU preparation')
        write(prep/'ready.json',{'state':'cpu_preparation_complete','commit':manifest['commit'],
            'release':str(source),'source_archive_sha256':manifest['archive_sha256'],
            'operation_sha256':manifest['operation_sha256'],'prepared':[{'path':str(p),'sha256':sha(p)} for p in prepared],
            'plan':str(plan_dir/'plan.json'),'plan_sha256':sha(plan_dir/'plan.json'),
            'future_study_output':str(study),'study_output_absent':True,'inputs_unchanged':True,
            'gpu_training_started':False,'formal_training_runs':0,
            'limitations':['No real GPU training/export occurred; GPU effect and anchor are unverified']})
        status['state']='cpu_preparation_complete'; status['finished_at']=time.time(); write(prep/'status.json',status)
    except BaseException as exc:
        status['state']='failed'; status['error']=type(exc).__name__+': '+str(exc)
        status['finished_at']=time.time(); write(prep/'status.json',status); raise

if __name__=='__main__': main()
