#!/usr/bin/env bash
set -euo pipefail
url='https://github.com/zhengli97/PromptKD/releases/download/datasets/stanford_cars.zip'
total=1957803555
pieces=8
chunk=$(((total + pieces - 1) / pieces))
chunk_dir='/root/autodl-tmp/textconsistency/data/archives/汽车数据分片'
target='/root/autodl-tmp/textconsistency/data/archives/stanford_cars.zip'
mkdir -p "$chunk_dir"
pids=()
for index in $(seq 0 $((pieces - 1))); do
  start=$((index * chunk))
  end=$((start + chunk - 1))
  if ((end >= total)); then end=$((total - 1)); fi
  part=$(printf '%s/分片-%02d' "$chunk_dir" "$index")
  curl -L --fail --retry 8 --retry-delay 5 --connect-timeout 30 --range "$start-$end" --output "$part.tmp" "$url" > "$part.log" 2>&1 &
  pids+=("$!")
done
for pid in "${pids[@]}"; do wait "$pid"; done
for index in $(seq 0 $((pieces - 1))); do
  start=$((index * chunk))
  end=$((start + chunk - 1))
  if ((end >= total)); then end=$((total - 1)); fi
  part=$(printf '%s/分片-%02d' "$chunk_dir" "$index")
  expected=$((end - start + 1))
  actual=$(stat -c %s "$part.tmp")
  if ((actual != expected)); then echo "分片大小错误: $index $actual $expected" >&2; exit 1; fi
  mv "$part.tmp" "$part"
done
cat "$chunk_dir"/分片-* > "$target.tmp"
actual_total=$(stat -c %s "$target.tmp")
if ((actual_total != total)); then echo "合并大小错误: $actual_total $total" >&2; exit 1; fi
mv "$target.tmp" "$target"
sha256sum "$target" > '/root/autodl-tmp/textconsistency/preparation/剩余两数据集-20260917-03cc19f/汽车归档SHA256.txt'
