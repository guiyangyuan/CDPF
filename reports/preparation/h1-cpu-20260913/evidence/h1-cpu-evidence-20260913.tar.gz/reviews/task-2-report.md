# Task 2 report: weighted non-target KD integration and provenance

## Result

The validated TextConsistency path now accepts `TRAINER.TEXTCONSISTENCY.KD_LOSS_MODE` with the historical default `full_kl` and the new `weighted_nckd` value. The runtime passes the declared mode into the real loss, preserves teacher CE updates, and records an exact versioned loss identity in the model signature and run provenance. Run manifests, checkpoints, and evaluation metrics therefore carry the declared mode, KD temperature, effective KD coefficient, active state, and non-target weighting definition.

Checkpoint loading compares both the model signature and top-level training provenance before loading parameter tensors. A changed or missing loss identity, or a same-shape checkpoint from the other loss mode, is rejected before model state mutates. Existing source SHA-256 checks are unchanged.

The summary audit accepts loss-identity omission only for legacy `full_kl` records. Explicit `weighted_nckd` protocols require complete identity in configs, manifests, model signatures, and metrics. Adding weighted identity to a default/historical full-KL record, changing a field, or dropping a required field is rejected.

Non-default modes are rejected in `train.py` for trainers outside the three validated TextConsistency implementations. The legacy `run_pilot.py` queue was not changed and therefore continues to exercise the default full-KL path.

## RED

Tests were added before production changes and run with:

```text
set -o pipefail; env PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest -v repro.test_trainers tests.test_train_config_cleanup repro.test_runner 2>&1 | tee ../task-2-red.log
```

Result: exit 1, 28 tests run, 12 failures and 2 errors. The failures showed the intended missing behavior: weighted mode still selected full KL; mode and identity were absent from runtime metadata; checkpoints accepted cross-mode or missing identity; unknown and unsupported modes were not rejected; audits ignored weighted/missing identities; the config had no historical default.

## GREEN

Focused verification:

```text
set -o pipefail; env PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest -v repro.test_trainers tests.test_train_config_cleanup repro.test_runner 2>&1 | tee ../task-2-green-focused.log
```

Result: exit 0, 28 tests run, all passed.

Full-suite verification:

```text
set -o pipefail; env PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest discover -s tests -v 2>&1 | tee ../task-2-full-suite.log
```

Result: exit 0, 148 tests run in 8.347 seconds, all passed.

The integration tests use the real tiny CLIP architecture, trainers, losses, and SGD optimizer for one CPU update. They verify weighted loss selection against the independently invoked loss contract, teacher-branch parameter updates through CE, frozen CLIP parameter equality, full-KL and weighted checkpoint roundtrips for student/teacher/ensemble, metadata in the manifest and metrics, pre-mutation identity rejection, and inactive weighted identity for the teacherless baseline.

## Files changed

- `train.py`
- `trainers/textconsistency_runtime.py`
- `trainers/textconsistency_common.py` (checkpoint provenance gate only)
- `scripts/repro/summarize.py`
- `tests/repro/test_trainers.py`
- `tests/repro/test_runner.py`
- `tests/test_train_config_cleanup.py`
- `.superpowers/sdd/2026-09-12-h1-cpu/task-2-report.md`

## Residual concerns

No GPU experiment or formal H1 run was performed. The tiny CPU optimizer steps are integration tests only. A future weighted experiment protocol must explicitly declare `kd_loss_mode: weighted_nckd`; missing identity intentionally continues to mean legacy full KL and can never authenticate a weighted control. Because the source digest remains strict, checkpoints produced from old source snapshots cannot be relabelled under this implementation.

## Review correction 1: sparse audit fail-closed behavior

The first review identified H-001: `read_metric` and `collect` conditioned loss-identity checks on optional KD protocol fields, allowing a sparse protocol to relabel legacy full-KL records as `weighted_nckd`. It also identified that non-finite loss scalars reached model/asset setup because `NaN` evaded the old inequality checks.

RED command:

```text
set -o pipefail; env PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest -v repro.test_trainers repro.test_runner 2>&1 | tee ../task-2-fix1-red.log
```

Result: exit 1, 29 tests run, 10 failures. The failures reproduced all four non-finite scalar bypasses originally covered by the test, direct `read_metric` acceptance of weighted identity under default full KL, sparse weighted and unknown protocols, and sparse metric/manifest/config acceptance of weighted metadata.

GREEN focused command:

```text
set -o pipefail; env PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest -v repro.test_trainers repro.test_runner 2>&1 | tee ../task-2-fix1-green-focused.log
```

Result: exit 0, 29 tests run, all passed. The final cases cover all five loss scalars, complete top-level and model-signature identities, training and evaluation configs, manifests, metrics, unknown modes, insufficient weighted protocols, and unchanged acceptance of genuinely legacy sparse full-KL records.

Final full-suite command:

```text
set -o pipefail; env PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest discover -s tests -v 2>&1 | tee ../task-2-fix1-full-suite.log
```

Result: exit 0, 152 tests run in 8.742 seconds, all passed.

The correction validates the declared mode on every direct metric read, requires the complete fixed protocol needed to authenticate weighted results, checks any available sparse manifest and effective configs, and rejects malformed, mismatched, partial, or non-finite identities. Runtime validation now rejects non-finite KD temperature and every loss coefficient before asset loading. Source SHA-256 and checkpoint rules remain unchanged.

## Final review correction: modern full-KL context

The whole-branch review found M-001: a sparse protocol could retain modern full-KL identities while omitting expected KD weight context, allowing protocol temperature 2, metric temperature 2, manifest temperature 9, and config temperature 7 to aggregate successfully. The bounded correction rejects modern identities or explicit mode markers unless the audit has an expected KD weight and temperature. Sparse legacy full-KL records remain accepted only when loss identity and `KD_LOSS_MODE` markers are absent throughout the available artifacts.

RED command:

```text
set -o pipefail; env PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest -v repro.test_runner 2>&1 | tee ../task-2-final-fix-red.log
```

Result: exit 1, 18 tests run, 2 failures. The direct metric reader accepted a modern full-KL identity without expected weight/temperature, and the exact T2/T9/T7 sparse fixture returned aggregate rows.

GREEN focused command:

```text
set -o pipefail; env PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest -v repro.test_runner 2>&1 | tee ../task-2-final-fix-green-focused.log
```

Result: exit 0, 18 tests run, all passed. Final coverage also verifies that a default sparse protocol cannot reinterpret a partially retained modern full-KL manifest or effective config as legacy when metrics have been stripped.

Final full-suite command:

```text
set -o pipefail; env PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest discover -s tests -v 2>&1 | tee ../task-2-final-fix-full-suite.log
```

Result: exit 0, 153 tests run in 8.579 seconds, all passed.
