from pathlib import Path
import datetime,hashlib,json,platform,shutil,subprocess
import torch
base=Path('/root/autodl-tmp/textconsistency');prep=base/'setup-logs/h1-validation-20260913-efcd3db';plan_path=prep/'future-plan/plan.json';expected='684ae3b6c6649cec536efb048e116443b0d8df136806569c18a20108b9a2dde6'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert platform.node()=='autodl-container-a03b4fb96c-09b042f2','Unexpected instance'
assert sha(plan_path)==expected,'Plan changed'
plan=json.loads(plan_path.read_text());root=Path(plan['output_root']);assert not root.exists() and not root.with_name(root.name+'.lock').exists(),'Study or lock already exists; inspect, never restart'
assert plan['state']=='planned_not_executed' and plan['training_budget']=={'maximum':4,'planned':4}
for x in plan['operations'].values():assert sha(x['path'])==x['sha256']
for c in plan['cases']:
 for path,key in (('prepared','prepared_sha256'),('future_config','future_config_sha256')):assert sha(c[path])==c[key]
assert torch.cuda.is_available(),'GPU is unavailable'
active=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'],text=True).strip();assert not active,'GPU already has a compute process'
info=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,memory.total,memory.free,driver_version','--format=csv,noheader'],text=True).strip()
a=torch.ones(2,2,device='cuda');assert float((a@a).sum().item())==8;torch.cuda.synchronize()
r={'state':'passed','time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hostname':platform.node(),'python':platform.python_version(),'torch':torch.__version__,'cuda':torch.version.cuda,'cuda_available':True,'cuda_kernel_check':True,'gpu':info,'compute_processes_before_check':active,'memory_max':Path('/sys/fs/cgroup/memory.max').read_text().strip(),'data_disk_free_bytes':shutil.disk_usage(base).free,'plan_path':str(plan_path),'plan_sha256':expected,'plan_identity_sha256':plan['plan_identity_sha256'],'operations':plan['operations'],'output_root':str(root),'study_absent':True,'lock_absent':True,'training_budget':plan['training_budget'],'formal_training_started':False}
print(json.dumps(r,indent=2))
