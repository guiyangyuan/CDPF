from pathlib import Path
import argparse,json,os,subprocess,sys
parser=argparse.ArgumentParser();parser.add_argument('--label',default='');parser.add_argument('--ready-plan',type=Path);args=parser.parse_args()
assert not args.label or all(c.isalnum() or c=='-' for c in args.label)
suffix='-'+args.label if args.label else ''
work=Path(__file__).resolve().parent;source=work.parent/'h1-cpu-20260912/source'
python=work.parent/'tc-venv/bin/python'
env=dict(os.environ,PYTHONPATH=str(source)+':'+str(source/'Dassl.pytorch')+':'+str(source/'tests'),OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='')
casekeys=['anchor-dtd','candidate-ucf101','candidate-dtd','candidate-fgvc_aircraft']
plan_dir=work/('no-cuda-guard-plan'+suffix); study=work/('no-cuda-guard-refused-study'+suffix)
assert not plan_dir.exists() and not study.exists()
commands=[[str(python),str(source/'scripts/repro/h1_study.py'),'plan','--prepared',*[str(work/'local-prepared-5145115'/k/'prepared.json') for k in casekeys],'--output-root',str(study),'--output-dir',str(plan_dir)], [str(python),str(source/'scripts/repro/h1_study.py'),'run','--plan',str(plan_dir/'plan.json')]]
for i,command in enumerate(commands):
    with (work/('no-cuda-command-'+str(i)+suffix+'.log')).open('w') as log:
        result=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
    if i==0: assert result.returncode==0 and not study.exists()
    else: assert result.returncode!=0
status=json.loads((study/'status.json').read_text())
assert status['state']=='failed' and status['commands']==[] and 'CUDA is required' in status['error']
ready=json.loads((args.ready_plan or work/'task2-local-plan-ready/plan.json').read_text())
assert not Path(ready['output_root']).exists()
result={'state':'passed','purpose':'Actual CLI rejection with CUDA masked; no training spawned','refusal_state':status['state'],'error':status['error'],'commands_spawned':0,'ready_study_absent':True,'guard_evidence_preserved':str(study),'formal_training_runs':0,'gpu_training_started':False}
result['implementation_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
(work/('no-cuda-verification'+suffix+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
