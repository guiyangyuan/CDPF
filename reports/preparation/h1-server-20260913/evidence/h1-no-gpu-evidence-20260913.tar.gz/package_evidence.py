"""Archive no-GPU preparation evidence once final verification is complete."""
from pathlib import Path
import argparse,hashlib,json,shutil,tarfile

work=Path(__file__).resolve().parent; repo=work.parent/'h1-cpu-20260912/source'
parser=argparse.ArgumentParser(); parser.add_argument('--verification',required=True,type=Path)
args=parser.parse_args(); final=json.loads(args.verification.read_text())
if final['state']!='passed' or final['gpu_training_started'] or final['formal_training_runs']!=0:
    raise ValueError('Final no-GPU verification is incomplete')
report=repo/'reports/preparation/h1-server-20260913'; stage=work/'evidence-package'
archive=work/'h1-no-gpu-evidence-20260913.tar.gz'
if stage.exists() or archive.exists() or (report/'backup-receipt.json').exists():
    raise FileExistsError('Evidence output already exists')
stage.mkdir()
extensions={'.json','.yaml','.py','.md','.log','.diff','.txt'}
for path in work.rglob('*'):
    relative=path.relative_to(work)
    if path.is_file() and path.suffix in extensions and not any(x in relative.parts for x in ('evidence-package','__pycache__')):
        target=stage/relative; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(path,target)
reviews=repo/'.superpowers/sdd/2026-09-13-h1-validation-prep'
for path in reviews.iterdir():
    if path.is_file() and path.suffix in extensions:
        target=stage/'reviews'/path.name; target.parent.mkdir(exist_ok=True); shutil.copy2(path,target)
shutil.copy2(repo/'docs/plans/2026-09-13-h1-validation-prep.md',stage/'implementation-plan.md')
def sha(path):
    with Path(path).open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()
files=[{'path':str(path.relative_to(stage)),'bytes':path.stat().st_size,'sha256':sha(path)}
       for path in sorted(stage.rglob('*')) if path.is_file()]
with tarfile.open(archive,'w:gz') as tar:
    for item in files:tar.add(stage/item['path'],arcname=item['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    if {item.name for item in tar.getmembers()}!={item['path'] for item in files}:
        raise ValueError('Archive members differ')
    for item in files:
        raw=tar.extractfile(item['path']).read()
        if len(raw)!=item['bytes'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:
            raise ValueError('Archive member mismatch: '+item['path'])
(report/'evidence').mkdir(exist_ok=True);shutil.copy2(archive,report/'evidence'/archive.name)
shutil.copy2(args.verification,report/'final-verification.json')
receipt={'archive':'evidence/'+archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),
    'files':files,'gpu_training_started':False,'formal_training_runs':0,'state':'verified_backup'}
(report/'backup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'files':len(files),'bytes':receipt['bytes'],'sha256':receipt['sha256']},indent=2))
