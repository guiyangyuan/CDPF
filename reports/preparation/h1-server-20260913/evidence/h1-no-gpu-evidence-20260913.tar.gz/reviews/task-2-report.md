# Task 2 report: fixed H1 study planner, executor, and analysis

Status: DONE

Commits:

- `28a84a2` (`feat: add fixed H1 validation queue`)
- `efcd3db` (`fix: bind H1 queue stage evidence`)

Committed owned files only:

- `scripts/repro/h1_study.py`
- `scripts/repro/h1_analysis.py`
- `tests/repro/test_h1_study.py`
- `tests/repro/test_h1_analysis.py`
- `docs/H1_VALIDATION_STUDY.md`

The controller-owned `PROJECT_STATUS.md` modification and
`reports/preparation/h1-server-20260913/` remain untouched and uncommitted by
Task 2. This report is the required SDD handoff and is not part of the owned
implementation commit.

## Implemented boundary

The planner accepts exactly four independently authenticated Task 1 receipts
in this order: DTD/full_kl anchor, then UCF101, DTD, and FGVC Aircraft
weighted_nckd candidates. Every case is seed 1 and uses the complete Task 1
fixed protocol (16 shots, 20 epochs, Base val, ViT-B/16, fp32, T2, KD1,
teacher CE1, last_step, no automatic test, sequential export workers0).

Planning calls Task 1 `load_prepared` and `build_train_command`, verifies that
the prepared source root is the current checkout, reads actual historical
JSON/NPZ and config bytes for hashes, rejects input/output aliases and existing
outputs, and writes a sealed `planned_not_executed` plan. It does not create
the future study root or invoke CUDA, model construction, export, or training.

The plan contains 13 immutable stages: anchor train/export/audit; each of the
three candidate train/export/analysis sequences; and final aggregation. The
executor strictly reloads and reconstructs the plan before creating the study
root, then uses an exclusive lock. After the study root exists, per-stage
checks authenticate inputs directly and do not call the fresh-output command
builder. This permits legitimate prior stage outputs while still refusing any
retry, resume, or preexisting stage directory. Every subprocess is argv-only
with no shell. No-CUDA rejection occurs before the first subprocess.

Each stage records an atomic command JSON with argv/hash, return code,
stdout/stderr, full actual before/after input manifests and their hashes, and
output evidence. Dynamic inputs are recomputed from actual prior-stage files
and compared with the prior stage's validated output evidence before the
subprocess is spawned and again after it exits.

Training validation reuses Task 1 `validate_new_checkpoint`; export validation
reuses Task 1 `load_export` and binds its prepared receipt, seed, source,
model directory, and complete checkpoint identity to the exact planned case
and validated train evidence. The executor independently recomputes and
compares the full anchor, candidate, and aggregate reports after their
subprocesses finish. Spawn failures, nonzero exits, input changes,
checkpoint/export failures, and analysis failures are fail-fast. Anchor and
final guard failures leave `stopped`; operational failures leave `failed`;
only all 13 passing stages leave `passed`.

Analysis reloads the authenticated current Task 1 export and original
historical export. Anchor S/T/M are compared with historical S1/T1/M using
exact argmax equality and the frozen `rtol=1e-5, atol=1e-4`, with max absolute
errors. Candidate analysis independently calculates S, T, M, ensemble, and
fixed `.5*(S+M)` metrics and historical C+M logits, C+M probability, and
S0+M logits comparators. Current M must match historical M under the same
prediction and numeric guards.

Aggregation requires exactly one complete candidate per dataset and gives
each dataset equal weight. Guard decisions are made with stdlib
`fractions.Fraction` from validated integer `correct/total` counts. This fixes
the exact-tie boundary where float subtraction could produce
`+3.552713678800501e-15` and incorrectly satisfy strict `>0`. Display deltas
remain floats, and exact macro/delta fractions are retained in
`exact_guard_arithmetic_pct`. No epsilon or threshold changed.

## Exact CPU plan CLI

From the repository root:

```bash
PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
/Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python \
  scripts/repro/h1_study.py plan \
  --prepared \
    ../../h1-prep-20260913/local-prepared-5145115/anchor-dtd/prepared.json \
    ../../h1-prep-20260913/local-prepared-5145115/candidate-ucf101/prepared.json \
    ../../h1-prep-20260913/local-prepared-5145115/candidate-dtd/prepared.json \
    ../../h1-prep-20260913/local-prepared-5145115/candidate-fgvc_aircraft/prepared.json \
  --output-root ../../h1-prep-20260913/task2-local-study-ready-never-run \
  --output-dir ../../h1-prep-20260913/task2-local-plan-ready
```

This exact local command passed for commit `28a84a2`. Its historical plan is:

`../../h1-prep-20260913/task2-local-plan-ready/plan.json`

Its `plan_identity_sha256` is
`c1ae7548277c0d0eeef11b5055f4e75054128a0b12b44a885ce20f44456a4b5d`.
Its operation bindings were:

- `train.py`: `6300a16139e2995da79b1ecffd55c5afd46185439630c855f0a5e793b0b2d927`
- `h1_validation.py`: `b00cc3d35e3c9279e0f9a7e1ba7af621df3abf382076ae4f8ea6523edd89554b`
- `h1_analysis.py`: `79bd00013b1b9f023b8e7d3baf31b7b751bea49c1e693d50becff222a1f5fefc`
- `h1_study.py`: `e300f6ab7fd1a400ee8628f9f4926813453a96b9647f4515b5f80b34f849d1f4`

Review fix `efcd3db` changed `h1_study.py`; its current SHA-256 is
`c494dba3661ce4e222793af7f84f1e5c90e66900d6f726362962c28c7b239a00`.
Therefore the historical plan above is intentionally invalid under the fixed
executor. Per controller direction, Task 2 did not regenerate the four-receipt
plan after the fix; deployment must run the same CPU plan CLI into fresh plan
and study paths and retain that new path and identity.

Strict plan reload/reconstruction passed after generation: 13 stages, fixed
four-train budget, state `planned_not_executed`, and the reserved study root
does not exist. Evidence:
`../../h1-prep-20260913/task2-real-plan-ready.log` and
`../../h1-prep-20260913/task2-real-plan-ready-revalidate.log`.

## Future GPU-only run CLI

```bash
PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 \
/Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python \
  scripts/repro/h1_study.py run \
  --plan /absolute/plan-artifact/plan.json
```

Task 2 did not invoke this command. The deployed host must generate its own
plan from that host's authenticated receipts because plan paths and transform
bindings are intentionally machine-absolute. The local plan above remains
valid for its current local paths and code hashes only.

## Output schemas needed by deployment and audit

`plan.json` top-level keys are exactly:

```text
schema_version, state, study, plan_path, output_root, python,
training_budget, protocol, cases, stages, operations, plan_identity_sha256
```

Each case binds:

```text
case_id, role, dataset_key, seed, mode,
prepared, prepared_sha256, prepared_identity_sha256,
future_config, future_config_sha256,
historical_export, historical_export_sha256,
historical_npz, historical_npz_sha256,
source_sha256, loss_identity
```

Each stage binds:

```text
stage_id, case_id, kind, argv, argv_sha256, output_dir, result_path
```

`status.json` contains `schema_version`, `state`, plan path/hash,
`started_at`, an ordered `commands` list, and on termination `finished_at`;
failures also include `error`. Each command summary points to
`logs/<stage-id>.json`. Command logs contain stage/case/kind, argv/hash,
timestamps, return code, stdout/stderr, complete actual before/after input
manifests, their digests and immutability result, plus validated output
evidence on success.

Case `analysis.json` contains status/schema/kind, dataset/seed/mode, fixed
tolerance or fixed alpha, current metrics, comparisons or comparators,
description/anchor guards, Base-only claims, and current/historical export
paths and hashes. `aggregate.json` contains status/schema/kind, case count,
seed/candidate/weighting, per-dataset and macro accuracies, float deltas,
`exact_guard_arithmetic_pct`, fixed guards, the three revalidated case
reports, analysis input hashes, and limitations.

Task 1 exports remain the raw-array authority for labels/S/T/M/ensemble;
historical exports remain the authority for labels/C/S0/S1/M/T0/T1. The
analysis artifacts bind and recompute from those files rather than inventing
or copying planner scores.

## Test evidence

TDD evidence:

- Initial missing-module RED:
  `../../h1-prep-20260913/task2-red-01.log`
- Saved-plan/fresh-output regression RED/GREEN:
  `task2-plan-revalidate-red.log`, `task2-plan-revalidate-green.log`
- Source binding and spawn-log RED/GREEN:
  `task2-self-review-red.log`, `task2-self-review-green.log`
- Actual historical-byte mutation RED:
  `task2-actual-hash-red.log`
- Exact rational tie RED/GREEN:
  `task2-fraction-guard-red.log`, `task2-fraction-guard-green.log`
- Review round 1 blocker RED:
  `../../h1-prep-20260913/task2-review-round1-red.log`
- Dynamic evidence and full-report GREEN:
  `../../h1-prep-20260913/task2-review-round1-green-01.log`,
  `../../h1-prep-20260913/task2-review-round1-green-03.log`

Final verification:

- Review-fix focused: 24/24 passed in 0.966 seconds.
  `../../h1-prep-20260913/task2-review-round1-focused.log`
- Review-fix full suite: 193/193 passed in 11.071 seconds.
  `../../h1-prep-20260913/task2-review-round1-full.log`
- `git diff --check` and AST parsing passed before the final suite/commit.

Tests use temporary real JSON/NPZ/config inputs, actual files for mutation
checks, and tiny subprocess commands that create stage directories and
artifacts. They cover wrong seed/mode/order, duplicate receipts, source and
path aliases, missing/skipped anchor, changed receipt/config/historical bytes,
preexisting outputs, no CUDA, exclusive no-reuse behavior, subprocess failure,
ordering/fail-fast behavior, anchor tolerance failures, description-baseline
drift, partial/mixed exports and reports, non-finite arrays, invalid counts,
equal-dataset guards, negative guard outcomes, the exact-tie boundary,
mutation of a real prior-stage artifact during a subprocess, a same-case
export from a different checkpoint, and a forged minimal anchor report. The
fake success path creates and validates all 13 realistic stage output trees.

## Remaining operational concerns

- The real CUDA train/export path was intentionally not run in Task 2. It is
  authenticated by Task 1 and exercised here only through tiny fake queue
  subprocesses plus the existing full CPU test suite.
- The historical local ready plan contains absolute local paths and the
  pre-fix `h1_study.py` hash. Server deployment must run the CPU plan command
  after server-local Task 1 preparation and use the newly generated plan;
  copying the historical local plan is expected to fail.
- Any code, prepared input, historical export, config, source metadata, or
  plan change invalidates the sealed plan. This is deliberate.
- A stopped or failed queue is evidence to preserve. There is no automatic or
  manual resume/retry interface in these scripts.

No server action, GPU power change, real-data training, export, or queue run
was performed by Task 2.
