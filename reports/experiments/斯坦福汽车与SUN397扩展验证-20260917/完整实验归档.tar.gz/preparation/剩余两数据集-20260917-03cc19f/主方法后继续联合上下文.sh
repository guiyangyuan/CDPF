#!/usr/bin/env bash
set -u
prep_dir=/root/autodl-tmp/textconsistency/preparation/剩余两数据集-20260917-03cc19f
main_status=/root/autodl-tmp/textconsistency/runs/投稿剩余两数据集主方法-20260917/执行状态.json
summary_file="$prep_dir/剩余两数据集GPU执行状态.txt"
echo "$(date -Is) 等待主方法PID 1702" >> "$summary_file"
while kill -0 1702 2>/dev/null; do sleep 20; done
if ! grep -q '"状态": "完成"' "$main_status"; then
  echo "$(date -Is) 主方法未完成，停止后续" >> "$summary_file"
  exit 21
fi
echo "$(date -Is) 主方法完成，启动CoCoOp" >> "$summary_file"
cd /root/autodl-tmp/textconsistency/releases/投稿标准基线-20260916-fc59a83
PYTHONPATH=/root/autodl-tmp/textconsistency/releases/投稿标准基线-20260916-fc59a83:/root/autodl-tmp/textconsistency/releases/投稿标准基线-20260916-fc59a83/Dassl.pytorch /root/autodl-tmp/textconsistency/.venv/bin/python -B scripts/repro/运行三数据集联合上下文基线.py 执行阶段 --plan-path "$prep_dir/服务器核验/联合上下文剩余两数据集计划.json" --stage 剩余两数据集 > "$prep_dir/联合上下文正式执行日志.txt" 2>&1
rc=$?
echo "$(date -Is) CoCoOp退出码 $rc" >> "$summary_file"
exit "$rc"
