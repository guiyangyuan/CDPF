"""Independent local audit of downloaded H1 files and NumPy/Fraction metrics.
No model inference/training; immutable remote paths are mapped for reading only.
"""
from pathlib import Path
from fractions import Fraction
import argparse,copy,hashlib,json,math,re
import numpy as np
import torch,yaml
p=argparse.ArgumentParser();p.add_argument('--backup',type=Path,required=True);args=p.parse_args()
w=Path(__file__).resolve().parent;repo=w.parent/'github-publish/textconsistency_v2_tune';unpacked=args.backup/'unpacked'
base='/root/autodl-tmp/textconsistency';prefixes={base+'/runs/h1-validation-20260913-efcd3db':unpacked/'study',base+'/setup-logs/h1-validation-20260913-efcd3db':unpacked/'preparation',base+'/setup-logs/h1-gpu-start-20260913-efcd3db':unpacked/'launch'}
def mapped(path):
 for prefix,target in prefixes.items():
  if str(path)==prefix or str(path).startswith(prefix+'/'):return target/str(path)[len(prefix):].lstrip('/')
 raise ValueError('Unmapped result path: '+str(path))
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def arrays(p):
 with np.load(p,allow_pickle=False) as raw:return {k:raw[k].copy() for k in raw.files}
def logprob(x):
 x=np.asarray(x,dtype=np.float64);return x-np.logaddexp.reduce(x,axis=1)[:,None]
def metrics(x,y,other=None):
 lp=logprob(x)
 prob=np.exp(lp)
 if other is not None:
  other_lp=logprob(other);prob=.5*prob+.5*np.exp(other_lp);lp=np.logaddexp(lp,other_lp)-math.log(2)
 n=len(y);correct=int(np.count_nonzero(np.argmax(prob,axis=1)==y));top=np.partition(prob,-2,axis=1)[:,-2:]
 return {'correct':correct,'total':n,'accuracy_pct':100*correct/n,'nll':float(-lp[np.arange(n),y].mean()),'multiclass_brier':float((np.sum(prob*prob,axis=1)-2*prob[np.arange(n),y]+1).mean()),'probability_top1_top2_margin':float((top[:,1]-top[:,0]).mean())}
maximum_float_error=0.0;checked_metrics=0
def check_metrics(expected,actual):
 global maximum_float_error,checked_metrics
 assert set(expected)==set(actual)
 for key,value in expected.items():
  if key in ('correct','total','accuracy_pct'):assert actual[key]==value,(key,actual[key],value)
  else:
   delta=abs(actual[key]-value);assert delta<=1e-10,(key,delta);maximum_float_error=max(maximum_float_error,delta)
 checked_metrics+=1
plan=read(unpacked/'preparation/future-plan/plan.json');assert sha(unpacked/'preparation/future-plan/plan.json')=='684ae3b6c6649cec536efb048e116443b0d8df136806569c18a20108b9a2dde6'
status=read(unpacked/'study/status.json');assert status['state'] in ('passed','stopped','failed')
backup=read(args.backup/'backup-verification.json');assert backup['state']=='passed'
local_cases={c['dataset']:c for c in read(w.parent/'h1-prep-20260913/local-cases.json')};case_results=[];stages=[]
for index,command in enumerate(status['commands']):
 stage=plan['stages'][index];assert stage['stage_id']==command['stage_id'];log=read(mapped(command['log']))
 assert log['argv']==stage['argv'] and log['kind']==stage['kind'] and log['case_id']==stage['case_id']
 assert log.get('inputs_immutable') is True and log['input_snapshot_before']==log['input_snapshot_after']
 stages.append({'stage_id':stage['stage_id'],'kind':stage['kind'],'case_id':stage['case_id'],'status':command['status'],'returncode':log['returncode'],'started_at':log['started_at'],'finished_at':log['finished_at'],'inputs_immutable':True})
for case in plan['cases']:
 key=case['case_id'];root=unpacked/'study/cases'/key;export_path=root/'export/export.json'
 if not export_path.exists():continue
 e=read(export_path);prepared_path=mapped(case['prepared']);prep=read(prepared_path)
 assert sha(prepared_path)==case['prepared_sha256']==e['prepared_sha256']
 for k in ('dataset_key','seed','mode','source_sha256','loss_identity','prepared_identity_sha256'):assert e[k]==prep[k]
 assert e['source_sha256']=='387ea6e46aa0fa6cba5109e64baab94a548b35c200a1945267d392bc35a36677'
 checkpoint=e['checkpoint'];model_dir=root/'model';assert mapped(checkpoint['model_dir'])==model_dir
 for k in ('checkpoint','manifest','effective_config'):assert sha(mapped(checkpoint[k]))==checkpoint[k+'_sha256']
 manifest=read(model_dir/'run_manifest.json');config=yaml.safe_load((model_dir/'effective_config.yaml').read_text());expected=copy.deepcopy(prep['future_config']);expected['OUTPUT_DIR']=checkpoint['model_dir'];assert config==expected
 state=torch.load(mapped(checkpoint['checkpoint']),map_location='cpu',weights_only=False);assert state['epoch']==20 and state['repro_signature']==prep['expected_model_signature']
 for k,v in {'code_sha256':prep['source_sha256'],'loss_identity':prep['loss_identity'],'seed':1,'shots':16,'subsample':'base','model_signature':prep['expected_model_signature'],'trainable_parameters':prep['expected_trainable_parameters']}.items():assert manifest[k]==v and state['run_provenance'][k]==v
 tensors=state['state_dict'];assert all(torch.is_tensor(v) and torch.isfinite(v).all().item() for v in tensors.values());assert sum(v.numel() for k,v in tensors.items() if not k.endswith(('token_prefix','token_suffix')))==prep['expected_trainable_parameters']
 npz=Path(e['npz']);npz=(export_path.parent/npz) if not npz.is_absolute() else mapped(npz);assert sha(npz)==e['npz_sha256'];current=arrays(npz)
 old_path=Path(local_cases[case['dataset_key']]['historical_export']);old=read(old_path);assert sha(old_path)==case['historical_export_sha256']
 old_npz=old_path.with_name('logits.npz');assert sha(old_npz)==case['historical_npz_sha256'];history=arrays(old_npz)
 assert e['rows']==old['rows'] and e['class_order']==old['class_order'] and np.array_equal(current['labels'],history['labels'])
 y=current['labels'];assert y.dtype==np.int64 and set(current)=={'labels','S','T','M','ensemble'}
 for k in ('S','T','M','ensemble'):assert current[k].dtype==np.float32 and current[k].shape==(len(y),len(e['class_order'])) and np.isfinite(current[k]).all()
 assert np.array_equal(current['ensemble'],np.float32(.5)*(current['S']+current['T']))
 analysis_path=root/'analysis/analysis.json'
 if not analysis_path.exists():continue
 a=read(analysis_path);assert a['current_export_sha256']==sha(export_path) and a['historical_export_sha256']==sha(old_path)
 allmetrics={k:metrics(current[k],y) for k in ('S','T','M','ensemble')};allmetrics['S+M_logits']=metrics(.5*(current['S'].astype('float64')+current['M'].astype('float64')),y)
 for k,v in allmetrics.items():check_metrics(v,a['metrics' if case['mode']=='full_kl' else 'current_metrics'][k])
 if case['mode']=='full_kl':
  comparisons={}
  for k,oldk in {'S':'S1','T':'T1','M':'M'}.items():
   eq=np.array_equal(current[k].argmax(1),history[oldk].argmax(1));close=np.allclose(current[k],history[oldk],rtol=1e-5,atol=1e-4);error=float(np.abs(current[k].astype('float64')-history[oldk].astype('float64')).max());assert a['comparisons'][k]['max_abs_error']==error and a['comparisons'][k]['prediction_exact_equal']==eq and a['comparisons'][k]['logits_allclose']==close;comparisons[k]={'predictions_equal':bool(eq),'allclose':bool(close),'max_abs_error':error}
  assert a['guards']['all_passed']==all(x['predictions_equal'] and x['allclose'] for x in comparisons.values())
  case_results.append({'case_id':key,'mode':case['mode'],'dataset':case['dataset_key'],'status':a['status'],'comparisons':comparisons,'metrics':allmetrics})
 else:
  assert np.array_equal(current['M'].argmax(1),history['M'].argmax(1)) and np.allclose(current['M'],history['M'],rtol=1e-5,atol=1e-4)
  comparisons={'C+M_logits':metrics(.5*(history['C'].astype('float64')+history['M'].astype('float64')),y),'C+M_probability':metrics(history['C'],y,history['M']),'S0+M_logits':metrics(.5*(history['S0'].astype('float64')+history['M'].astype('float64')),y)}
  for k,v in comparisons.items():check_metrics(v,a['comparators'][k])
  old_s1=metrics(.5*(history['S1'].astype('float64')+history['M'].astype('float64')),y)
  teacher={'predictions_equal':bool(np.array_equal(current['T'].argmax(1),history['T1'].argmax(1))),'max_abs_error':float(np.abs(current['T'].astype('float64')-history['T1'].astype('float64')).max())}
  case_results.append({'case_id':key,'mode':case['mode'],'dataset':case['dataset_key'],'status':a['status'],'metrics':allmetrics,'comparators':comparisons,'historical_S1_plus_M':old_s1,'teacher_vs_historical_T1':teacher})
candidates=[r for r in case_results if r['mode']=='weighted_nckd'];aggregate=None
if len(candidates)==3:
 aggregate_path=unpacked/'study/aggregate/aggregate.json';assert aggregate_path.exists();saved=read(aggregate_path);deltas={};guards={};macro={}
 for name in ('S+M_logits','C+M_logits','C+M_probability','S0+M_logits'):
  ms=[r['metrics'][name] if name=='S+M_logits' else r['comparators'][name] for r in candidates];macro[name]=sum((Fraction(100*m['correct'],m['total']) for m in ms),Fraction())/3
 for name in ('C+M_logits','C+M_probability','S0+M_logits'):
  ds={r['dataset']:Fraction(100*(r['metrics']['S+M_logits']['correct']-r['comparators'][name]['correct']),r['metrics']['S+M_logits']['total']) for r in candidates};avg=sum(ds.values(),Fraction())/3;key='vs_'+name;guards[key]=avg>0 if name=='S0+M_logits' else avg>=0 and min(ds.values())>=-1;assert saved['guards'][key]==guards[key];assert saved['exact_guard_arithmetic_pct']['deltas'][key]['macro']==str(avg);deltas[key]={'datasets':{k:float(v) for k,v in ds.items()},'macro':float(avg),'exact_macro':str(avg)}
 guards['all_passed']=all(guards.values());assert saved['guards']['all_passed']==guards['all_passed'];assert saved['status']==('passed' if guards['all_passed'] else 'stopped')
 aggregate={'status':saved['status'],'macro_accuracy_pct':{k:float(v) for k,v in macro.items()},'deltas_pp':deltas,'guards':guards}
r={'state':'passed','study_state':status['state'],'source_commit':'efcd3dbb7d5515dde3a708d4093bc503f66eba0b','case_results':case_results,'aggregate':aggregate,'stages':stages,'formal_train_commands':sum(s['kind']=='train' for s in stages),'export_commands':sum(s['kind']=='export' for s in stages),'checked_metric_groups':checked_metrics,'metric_count_accuracy_match_exact':True,'max_continuous_metric_roundoff':maximum_float_error,'continuous_metric_tolerance':1e-10,'checkpoint_and_export_hash_bindings_verified':True,'analysis_uses_independent_numpy_fraction_math':True,'raw_export_files_modified':False,'novel_or_hm':False}
out=w/'independent-audit.json';assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ('state','study_state','formal_train_commands','export_commands','checked_metric_groups','max_continuous_metric_roundoff','aggregate')},indent=2))
