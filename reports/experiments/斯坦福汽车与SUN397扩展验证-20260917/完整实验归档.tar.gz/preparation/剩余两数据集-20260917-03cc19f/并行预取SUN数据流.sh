#!/usr/bin/env bash
set -euo pipefail
url='https://hf-mirror.com/datasets/Veiiaj3dad/CLIP-Prompt-learning-sun397/resolve/main/SUN397.tar.gz?download=true'
total=39077296924
chunk=268435456
parallel=8
pieces=$(((total + chunk - 1) / chunk))
work='/root/autodl-tmp/textconsistency/data/archives/SUN流式分片'
fifo='/root/autodl-tmp/textconsistency/preparation/剩余两数据集-20260917-03cc19f/SUN数据流管道'
mkdir -p "$work"
for batch_start in $(seq 0 "$parallel" $((pieces - 1))); do
  batch_end=$((batch_start + parallel - 1))
  if ((batch_end >= pieces)); then batch_end=$((pieces - 1)); fi
  echo "下载分片 $batch_start 到 $batch_end，共 $pieces 片"
  pids=()
  indexes=()
  for index in $(seq "$batch_start" "$batch_end"); do
    start=$((index * chunk))
    end=$((start + chunk - 1))
    if ((end >= total)); then end=$((total - 1)); fi
    part=$(printf '%s/分片-%03d' "$work" "$index")
    curl -L --fail --retry 20 --retry-all-errors --retry-delay 3 --connect-timeout 30 --range "$start-$end" --output "$part.tmp" "$url" > "$part.log" 2>&1 &
    pids+=("$!")
    indexes+=("$index")
  done
  failed=0
  for pid in "${pids[@]}"; do
    if ! wait "$pid"; then failed=1; fi
  done
  if ((failed != 0)); then echo "批次下载失败" >&2; exit 1; fi
  for index in "${indexes[@]}"; do
    start=$((index * chunk))
    end=$((start + chunk - 1))
    if ((end >= total)); then end=$((total - 1)); fi
    expected=$((end - start + 1))
    part=$(printf '%s/分片-%03d' "$work" "$index")
    actual=$(stat -c %s "$part.tmp")
    if ((actual != expected)); then echo "分片大小错误: $index $actual $expected" >&2; exit 1; fi
    cat "$part.tmp" > "$fifo"
    rm -f "$part.tmp" "$part.log"
  done
  echo "已送入 $((batch_end + 1))/$pieces 片"
done
rmdir "$work"
