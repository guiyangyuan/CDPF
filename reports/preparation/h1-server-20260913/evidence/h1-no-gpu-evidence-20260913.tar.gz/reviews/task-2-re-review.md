### Finding Disposition

- **ADDRESSED — dynamic stage inputs were absent from before/after snapshots.** `scripts/repro/h1_study.py:280` now derives the exact prior-stage dependencies for export, case-analysis, and aggregate stages, recomputes each complete directory manifest, and compares it with validated prior evidence. `scripts/repro/h1_study.py:473` and `scripts/repro/h1_study.py:503` capture those manifests before and after every subprocess and stop on either a pre-spawn mismatch or mutation during execution. The regression at `tests/repro/test_h1_study.py:252` mutates a trained-model artifact during export and verifies the command log records failed immutability. This fully addresses the first Important finding.
- **ADDRESSED — export/analysis evidence was insufficiently bound and allowed forged completion.** `scripts/repro/h1_study.py:371` now binds an export to the planned dataset, seed, mode, prepared path/hash/identity, source, exact training directory, and complete validated train checkpoint evidence. `scripts/repro/h1_study.py:400` independently reloads the authenticated current and historical exports and recomputes the complete anchor/candidate report; `scripts/repro/h1_study.py:419` does the same for aggregation. Exact payload equality rejects partial, mixed, or forged reports before candidate release. The negative tests at `tests/repro/test_h1_study.py:280` and `tests/repro/test_h1_study.py:310` cover a same-case export from a different checkpoint and a minimal forged passed anchor. This fully addresses the second Important finding.

### Spec Compliance

- ✅ Spec compliant for the two reviewed fixes. The fix preserves the frozen four-case protocol and queue order while adding the required cross-stage immutability and evidence chain. No model/trainer/dataset source changed in the fix package.

### Quality

#### Critical

- None.

#### Important

- None.

#### Minor

- `scripts/repro/h1_study.py:445`: the `stage_validator` annotation still declares a two-argument callable, while execution supplies `stage`, `plan`, and `completed_evidence` at `scripts/repro/h1_study.py:512`. Runtime behavior is correct because the default and updated tests accept three arguments, but the public type contract is stale and will mislead type checking and injected validators. Update the annotation to the three-argument signature.

### Verification Evidence

- `../../h1-prep-20260913/task2-review-round1-red.log:1` shows all three targeted regressions failing before the fix; `../../h1-prep-20260913/task2-review-round1-green-01.log:1` shows all three passing after it.
- `../../h1-prep-20260913/task2-review-round1-focused.log:27` reports 24/24 passing, and `../../h1-prep-20260913/task2-review-round1-full.log:196` reports 193/193 passing. These suites were not rerun during re-review.
- The previously recorded dataset stdout noise remains deferred in the ledger as directed and was not reopened.

### Assessment

**Task quality:** Approved

**Reasoning:** Both blocking audit gaps are closed with stage-aware manifests, exact cross-stage identity checks, independent report recomputation, and focused negative coverage. The remaining annotation mismatch is a non-runtime maintenance issue and does not block the future queue or later whole-branch review.

Check performed: read the supplied `28a84a2..efcd3db` fix package once, reviewed only the two original Important findings and fix-introduced paths, and inspected the provided test logs without rerunning tests.
