### Spec Compliance

- ❌ Issues found: the fixed cases, protocol, arithmetic, queue order, fresh-output rules, CUDA gate, and documentation comply, but the executor does not fully satisfy the required per-stage input immutability or the prohibition on forged/mixed stage evidence. See the two Important findings at `scripts/repro/h1_study.py:272` and `scripts/repro/h1_study.py:320`.

### Strengths

- `scripts/repro/h1_study.py:169` reconstructs exactly four authenticated receipts in the fixed DTD-anchor/UCF101/DTD/FGVC-Aircraft order, rejects duplicate or overlapping prepared directories, requires seed 1 and the prescribed modes, and rebuilds the sealed 13-stage plan before execution at `scripts/repro/h1_study.py:253`.
- `scripts/repro/h1_study.py:345` enforces a fresh root and exclusive lock, rejects no CUDA before the first subprocess at `scripts/repro/h1_study.py:370`, executes the anchor stages before any candidate, and leaves failed/stopped evidence atomically.
- `scripts/repro/h1_analysis.py:112` implements the exact S/T/M anchor prediction and `allclose(rtol=1e-5, atol=1e-4)` guards. `scripts/repro/h1_analysis.py:144` independently computes S/T/M/ensemble/S+M and all three historical comparators while enforcing the candidate M integrity check.
- `scripts/repro/h1_analysis.py:182` uses integer `correct/total` values and `Fraction` for equal-dataset macros and all fixed thresholds, including the strict `S0+M` macro `> 0` boundary at `scripts/repro/h1_analysis.py:247`.
- Focused risk check—Task 1 integration: `scripts/repro/h1_validation.py:951` confirms `load_export` revalidates its referenced prepared receipt, full epoch-20 checkpoint bundle, identities, rows/classes, arrays, transform, and tool hash. Focused risk check—fixed protocol: `scripts/repro/h1_validation.py:41` contains seed 1, 16 shots, 20 epochs, Base val, ViT-B/16, fp32, T2, KD1, teacher CE1, alpha .5, last-step, and workers 0. Focused risk check—real receipt layout: the actual prepared receipt uses the `historical_config.path`, `assets.clip/template`, `inventory.path`, `reference.path`, and `source_metadata[].path` fields covered by `scripts/repro/h1_study.py:84`.

### Issues

#### Critical (Must Fix)

- None.

#### Important (Should Fix)

- `scripts/repro/h1_study.py:272`: `_input_snapshot` hashes only the prepared-case records, operation scripts, and plan file, and the executor uses that same static snapshot around every subprocess at `scripts/repro/h1_study.py:375` and `scripts/repro/h1_study.py:402`. It omits the dynamic input to each later stage: the trained model/checkpoint for export, the current export for anchor/candidate analysis, and the three candidate analysis artifacts for aggregation. Therefore an export or analysis subprocess can alter its input artifact without making `inputs_immutable` false, contrary to the required per-stage model/export binding and before/after immutability evidence. Make snapshots stage-aware and include a canonical manifest/hash of every stage input on both sides of the subprocess; compare the export-stage model manifest to the validated train evidence, analysis-stage export hashes to the validated export evidence, and aggregate-stage analysis hashes to the validated candidate evidence. Add a tiny-command regression that mutates a prior-stage artifact and proves the queue fails with a command log.
- `scripts/repro/h1_study.py:320`: export validation accepts any authentic Task 1 export with the planned dataset and mode; it does not compare seed, prepared identity/source identity, checkpoint `model_dir`, or checkpoint hashes against the planned case and the preceding train result. The generic analysis branch at `scripts/repro/h1_study.py:326` is weaker still: an anchor JSON containing only `status: passed`, `analysis_kind: anchor_audit`, and the planned dataset passes without the required comparisons/guards/export hashes, so forged anchor completion can release candidate training. This misses the explicit no-mixed-checkpoint/no-forged-anchor requirement even though the shipped subprocesses normally produce richer artifacts. Bind every export field to the planned case and prior train evidence, and revalidate/recompute anchor and candidate analysis from their planned authenticated exports (or compare the complete expected schema and all input hashes) before marking a stage passed. Add negative tests for a same-dataset/mode export from a different checkpoint and a minimal forged `passed` anchor report.

#### Minor (Nice to Have)

- `../../h1-prep-20260913/task2-final-full-suite-2.log:196`: the reported full-suite log ends with three `SUBSAMPLE BASE CLASSES!` lines after `OK`. The suite passed 190/190, but the reviewer contract requires pristine test output; route or suppress these informational prints in tests when practical.

### Assessment

**Task quality:** Needs fixes

**Reasoning:** The fixed study definition, arithmetic, and fail-fast order are carefully implemented and well tested, and the controller independently confirmed the no-CUDA guard and exact historical-count arithmetic. The audit chain is not yet strong enough to prove that each stage consumed the exact immutable artifact produced by the preceding stage or to reject forged anchor evidence, so the future GPU queue should not be trusted until those bindings are added.

Check performed: read the supplied `5145115..28a84a2` review package once; inspected only the named Task 1 contract/protocol and actual receipt-field risks outside the diff; did not rerun focused or full suites.
