# Task 1 report: weighted non-target KD loss

## Changes

- Added the keyword-only `kd_loss_mode='full_kl'` argument to `training_losses`.
- Preserved the historical full-KL expression and operation order in the default/explicit `full_kl` branch.
- Added `weighted_nckd`: remove the true class before both conditional softmaxes, compute the detached teacher non-target mass by summing full-softmax non-target probabilities, multiply per-example conditional KL by that mass and `T^2`, then take the batch mean.
- Added eager validation for the mode, finite positive temperature, and finite nonnegative weights. Active weighted KD also validates teacher presence, compatible nonempty rank/shape, at least two classes, and `torch.long` in-range labels.
- Kept student CE, online teacher CE, negative entropy, teacher-less default behavior, and checkpoint loading unchanged.
- Added 10 focused tests covering frozen full-KL value/gradient exact equality; an independent full-KL-minus-binary-KL oracle for weighted NCKD value and student gradient; zero true-class KD gradient; KD teacher detachment with teacher CE gradients retained; conditional non-target normalization; class permutation and batch mean weighting; extreme-logit finiteness; two-class zero; disabled KD behavior; and invalid inputs/options.
- No shared mode tuple or validator was exposed; integration should use the exact strings `full_kl` and `weighted_nckd`.

## RED evidence

Exact command:

```bash
PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest repro.test_kd_losses -v
```

Initial result: `FAILED (failures=6, errors=15)` across 10 tests. The errors showed the missing `kd_loss_mode` keyword; failures showed nonfinite temperatures/weights were accepted. Full output: `../task-1-red.log`.

The first implementation run had one fixture-only failure in the frozen equality test because the test accidentally compared three independently sampled student tensors. The fixture was corrected to clone one tensor; no product-code change was needed for that failure.

## GREEN evidence

Focused command:

```bash
PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest repro.test_kd_losses -v
```

Final result: `Ran 10 tests in 0.093s` / `OK`. Full output: `../task-1-green-focused.log`.

Required full-suite command (run once before commit):

```bash
PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python -m unittest discover -s tests -v
```

Final result after the malformed-label/empty-batch review fix: `Ran 138 tests in 7.718s` / `OK`. Full output: `../task-1-green-full.log`.

## Concerns

- The weighted implementation intentionally supports two classes and returns finite exact zero because the conditional non-target distribution has one element.
- It intentionally performs no logit normalization, unweighted NCKD, DKD alpha/beta split, or gating.
- Runtime/config plumbing is outside this task; callers currently must pass the new keyword explicitly to select `weighted_nckd`.
