#!/usr/bin/env bash
set -euo pipefail
url='https://github.com/zhengli97/PromptKD/releases/download/datasets/stanford_cars.zip'
chunk_dir='/root/autodl-tmp/textconsistency/data/archives/汽车数据分片'
target='/root/autodl-tmp/textconsistency/data/archives/stanford_cars.zip'
resume_start=1163509040
resume_end=1223627224
resume_size=60118185
curl -L --fail --retry 20 --retry-all-errors --retry-delay 3 --connect-timeout 30 --range "$resume_start-$resume_end" --output "$chunk_dir/分片-04.补全.tmp" "$url"
actual_resume=$(stat -c %s "$chunk_dir/分片-04.补全.tmp")
if ((actual_resume != resume_size)); then echo "补全分片大小错误: $actual_resume $resume_size" >&2; exit 1; fi
cat "$chunk_dir/分片-04.补全.tmp" >> "$chunk_dir/分片-04.tmp"
rm -f "$chunk_dir/分片-04.补全.tmp"
total=1957803555
pieces=8
chunk=$(((total + pieces - 1) / pieces))
for index in $(seq 0 $((pieces - 1))); do
  start=$((index * chunk))
  end=$((start + chunk - 1))
  if ((end >= total)); then end=$((total - 1)); fi
  part=$(printf '%s/分片-%02d' "$chunk_dir" "$index")
  expected=$((end - start + 1))
  actual=$(stat -c %s "$part.tmp")
  if ((actual != expected)); then echo "分片大小错误: $index $actual $expected" >&2; exit 1; fi
  mv "$part.tmp" "$part"
done
cat "$chunk_dir"/分片-?? > "$target.tmp"
actual_total=$(stat -c %s "$target.tmp")
if ((actual_total != total)); then echo "合并大小错误: $actual_total $total" >&2; exit 1; fi
mv "$target.tmp" "$target"
sha256sum "$target" > '/root/autodl-tmp/textconsistency/preparation/剩余两数据集-20260917-03cc19f/汽车归档SHA256.txt'
python3 -u /root/autodl-tmp/textconsistency/preparation/剩余两数据集-20260917-03cc19f/scripts/repro/准备剩余两数据集数据.py 下载并核验 --data-root /root/autodl-tmp/textconsistency/data --archive-root /root/autodl-tmp/textconsistency/data/archives --receipt /root/autodl-tmp/textconsistency/preparation/剩余两数据集-20260917-03cc19f/数据下载收据.json
