"""Read-only mode/config comparison for the three planned datasets."""
import argparse,copy,json,sys
from pathlib import Path
work=Path(__file__).resolve().parent
repo=work/'source'
sys.path[:0]=[str(repo),str(repo/'Dassl.pytorch')]
from train import setup_cfg
from trainers.coop_textconsistency_v2_fg import CoOp_TextConsistency_V2_FG
from trainers.textconsistency_runtime import source_digest

output=work/'config-verification.json'
if output.exists(): raise FileExistsError(output)
rows=[]
for dataset in ('ucf101','dtd','fgvc_aircraft'):
 configs={}
 for mode in ('full_kl','weighted_nckd'):
  args=argparse.Namespace(root='/unused/data',output_dir='/unused/h1-output',resume='',seed=1,
   source_domains=None,target_domains=None,transforms=None,trainer='CoOp_TextConsistency_V2_FG',
   backbone='',head='',dataset_config_file=str(repo/f'configs/datasets/{dataset}.yaml'),
   config_file=str(repo/f'configs/repro/{dataset}.yaml'),
   opts=['TRAINER.TEXTCONSISTENCY.KD_LOSS_MODE',mode,'TRAINER.TEXTCONSISTENCY.KD_WEIGHT','1.0',
         'TRAINER.TEXTCONSISTENCY.AGGREGATION','hierarchical','TRAINER.TEXTCONSISTENCY.USE_FEATURE_ADAPTER','True',
         'DATASET.NUM_SHOTS','16','DATASET.SUBSAMPLE_CLASSES','base','OPTIM.MAX_EPOCH','20',
         'TRAINER.TEXTCONSISTENCY.DEVICE','cpu','USE_CUDA','False'])
  cfg=setup_cfg(args)
  checker=CoOp_TextConsistency_V2_FG.__new__(CoOp_TextConsistency_V2_FG)
  checker.check_cfg(cfg)
  configs[mode]=json.loads(json.dumps(cfg))
  tc=cfg.TRAINER.TEXTCONSISTENCY
  assert tc.KD_TEMP==2 and tc.KD_WEIGHT==1 and tc.ADAPTIVE_CE_WEIGHT==1 and tc.DIVERSITY_WEIGHT==0
  assert tc.ENSEMBLE_ALPHA==0.5 and tc.N_VIEWS==20 and tc.N_GROUPS==4
  assert cfg.OPTIM.MAX_EPOCH==20 and cfg.DATASET.NUM_SHOTS==16
 left=copy.deepcopy(configs['full_kl']);right=copy.deepcopy(configs['weighted_nckd'])
 left['TRAINER']['TEXTCONSISTENCY'].pop('KD_LOSS_MODE');right['TRAINER']['TEXTCONSISTENCY'].pop('KD_LOSS_MODE')
 assert left==right
 rows.append({'dataset':dataset,'same_except_loss_mode':True,'configs':configs})
result={'state':'passed','source_sha256':source_digest(),'cases':rows,'configuration_checks':6,
        'dataset_loaded':False,'model_loaded':False,'training_started':False,'gpu_verified':False}
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
