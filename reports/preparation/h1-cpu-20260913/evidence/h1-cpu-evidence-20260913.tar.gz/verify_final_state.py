"""Bind previously observed numeric checks to the final integrated source."""
from pathlib import Path
import hashlib,inspect,json,platform,re,subprocess,sys
import torch
work=Path(__file__).resolve().parent; root=work.parents[1]; repo=work/'source'
sys.path[:0]=[str(repo),str(repo/'Dassl.pytorch')]
from trainers.textconsistency_common import training_losses
from trainers.textconsistency_runtime import source_digest
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
output=work/'final-verification.json'
if output.exists(): raise FileExistsError(output)
prior=read(work/'saved-logit-verification.json'); configs=read(work/'config-verification.json')
current=source_digest()
assert prior['state']==configs['state']=='passed'
function_sha=hashlib.sha256(inspect.getsource(training_losses).encode()).hexdigest()
assert function_sha==prior['training_loss_function_sha256']
assert configs['source_sha256']==current
for path,digest in prior['inputs_sha256'].items(): assert sha(Path(path))==digest
log=work/'final-tests.log'; text=log.read_text(); matches=re.findall(r'Ran (\d+) tests in ([\d.]+)s',text)
assert len(matches)==1 and '\nOK\n' in text and 'FAILED (' not in text
num,seconds=matches[0]
product=['train.py','trainers/textconsistency_common.py','trainers/textconsistency_runtime.py','scripts/repro/summarize.py']
result={'state':'passed','verified_at_local_date':'2026-09-13',
 'implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
 'source_sha256':current,'product_file_sha256':{p:sha(repo/p) for p in product},
 'python':platform.python_version(),'torch':torch.__version__,'cuda_available':torch.cuda.is_available(),
 'suite':{'tests':int(num),'seconds':float(seconds),'returncode':0,'log_sha256':sha(log),
         'command':'PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 <tc-venv>/bin/python -m unittest discover -s tests -v'},
 'configs':{'checks':configs['configuration_checks'],'sha256':sha(work/'config-verification.json')},
 'historical_logits':{'records':prior['records'],'cases':prior['cases'],'default_exact_checks':prior['default_exact_checks'],
                      'weighted_chain_checks':prior['weighted_chain_checks'],'math_checked_source_sha256':prior['source_sha256'],
                      'loss_function_unchanged_at_final_source':True,'function_sha256':function_sha,
                      'max_value_error':prior['max_weighted_value_error'],'max_gradient_error':prior['max_weighted_gradient_error'],
                      'original_inputs_unchanged':True,'sha256':sha(work/'saved-logit-verification.json')},
 'scope':{'server_connected':False,'gpu_training_started':False,'formal_experiment_runs':0,
          'tiny_cpu_optimizer_steps_are_tests_only':True,'new_accuracy_claim':False,
          'independent_h1_gpu_orchestrator_prepared':False}}
output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
