from pathlib import Path,PurePosixPath
import argparse,hashlib,json,tarfile
p=argparse.ArgumentParser();p.add_argument('--directory',required=True,type=Path);a=p.parse_args();r=json.loads((a.directory/'h1-validation-20260913-42527-receipt.json').read_text());archive=a.directory/Path(r['archive']).name;out=a.directory/'unpacked'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert r['state']=='complete_backup' and r['study_state'] in ('passed','stopped','failed')
assert sha(archive)==r['archive_sha256'] and archive.stat().st_size==r['archive_bytes']
expected={x['path']:x for x in r['files']};assert len(expected)==len(r['files']) and not out.exists()
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(expected) and {x.name for x in members}==set(expected)
 for m in members:
  n=PurePosixPath(m.name);assert m.isfile() and not n.is_absolute() and '..' not in n.parts
  raw=tar.extractfile(m).read();assert len(raw)==expected[m.name]['bytes'] and hashlib.sha256(raw).hexdigest()==expected[m.name]['sha256']
 out.mkdir();tar.extractall(out,filter='data')
for name,item in expected.items():assert sha(out/name)==item['sha256']
result={'state':'passed','study_state':r['study_state'],'archive_bytes':r['archive_bytes'],'archive_sha256':r['archive_sha256'],'file_count':len(expected),'checkpoint_file_count':len(r['checkpoint_files']),'all_members_verified_before_and_after_extract':True,'output':str(out.resolve())}
(a.directory/'backup-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
