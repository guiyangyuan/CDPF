"""Compare image/sample/protocol identities across machines, excluding location/mtime."""
from pathlib import Path
import argparse,copy,json
p=argparse.ArgumentParser();p.add_argument('--remote-prepared',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
w=Path(__file__).resolve().parent;cases=json.loads((w/'local-cases.json').read_text());rows=[]
def normalized_config(x):
 x=copy.deepcopy(x);x['DATASET']['ROOT']='<data>';x['OUTPUT_DIR']='<output>';x['TRAINER']['TEXTCONSISTENCY']['CLIP_PATH']='<clip>';return x
for c in cases:
 l=json.loads((w/'local-prepared-5145115'/c['key']/'prepared.json').read_text());r=json.loads((a.remote_prepared/c['key']/'prepared.json').read_text())
 for key in ('source_sha256','loss_identity','protocol','sample_hashes','expected_model_signature','expected_trainable_parameters','tool'):
  assert l[key]==r[key],(c['key'],key)
 assert l['samples']['classes']==r['samples']['classes']
 for split in ('train','val','test'):
  stable=lambda items:[{k:x[k] for k in ('sample_id','label','classname','size')} for x in items]
  assert stable(l['samples'][split])==stable(r['samples'][split]),(c['key'],split)
 for split in ('train','val'):assert l['image_content'][split]==r['image_content'][split]
 for key in ('clip_sha256','template_sha256'):assert l['assets'][key]==r['assets'][key]
 assert normalized_config(l['future_config'])==normalized_config(r['future_config'])
 for key in ('repr','repr_sha256'):assert l['transform'][key]==r['transform'][key]
 for key in ('count','tensor_shape','tensor_dtype'):assert l['transform']['decoded_val'][key]==r['transform']['decoded_val'][key]
 for key in ('export_sha256','npz_sha256','rows','class_order','branches'):assert l['historical'][key]==r['historical'][key]
 rows.append({'case':c['key'],'relative_sample_order_equal':True,'sampled_image_content_equal':True,'normalized_config_equal':True,'source_assets_protocol_equal':True,'transform_spec_equal':True})
result={'state':'passed','cases':rows,'excluded_location_fields':['absolute source/data/output paths','file mtimes','decoded transform digest includes absolute path'],'formal_training_runs':0,'gpu_training_started':False}
assert not a.output.exists();a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
