"""Publish exact, lightweight evidence; model weights remain in verified full backup."""
from pathlib import Path
from fractions import Fraction
import csv, hashlib, io, json, shutil, tarfile

w = Path(__file__).resolve().parent
root = w.parent.parent
repo = w.parent / 'github-publish/textconsistency_v2_tune'
backup = root / 'outputs/textconsistency-h1-validation-20260913-42527'
unpacked = backup / 'unpacked'
report = repo / 'reports/experiments/h1-validation-20260913-42527'
evidence = report / 'evidence'
evidence.mkdir(exist_ok=True)

def read(p):
    return json.loads(p.read_text())

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

audit = read(w / 'independent-audit.json')
verified = read(backup / 'backup-verification.json')
receipt = read(backup / 'h1-validation-20260913-42527-receipt.json')
status = read(unpacked / 'study/status.json')
after = read(w / 'inputs-after.json')
assert audit['state'] == verified['state'] == 'passed'
assert status['state'] == audit['study_state'] == 'stopped'
assert after['all_match'] and len(after['files']) == 2516
assert len(status['commands']) == 13 and all(s['status'] == 'passed' for s in status['commands'][:12])
last = read(unpacked / 'study/logs/13-aggregate.json')
assert last['returncode'] == 2 and audit['aggregate']['guards']['all_passed'] is False
assert receipt['compute_processes_after'] == ''

copies = {
    'independent-audit.json': w / 'independent-audit.json',
    'completed-status.json': unpacked / 'study/status.json',
    'aggregate.json': unpacked / 'study/aggregate/aggregate.json',
    'backup-receipt.json': backup / 'h1-validation-20260913-42527-receipt.json',
    'backup-verification.json': backup / 'backup-verification.json',
}
for name, source in copies.items():
    if (report / name).exists():
        assert sha(report / name) == sha(source)
    else:
        shutil.copy2(source, report / name)

cases = [x for x in audit['case_results'] if x['mode'] == 'weighted_nckd']
columns = ['dataset', 'seed', 'split', 'role', 'method', 'correct', 'total', 'accuracy_pct', 'nll', 'multiclass_brier', 'probability_top1_top2_margin']
f = io.StringIO(newline='')
if True:
    writer = csv.DictWriter(f, fieldnames=columns)
    writer.writeheader()
    for case in audit['case_results']:
        for name, m in case['metrics'].items():
            role = 'anchor' if case['mode'] == 'full_kl' else ('fixed_candidate' if name == 'S+M_logits' else 'diagnostic')
            writer.writerow(dict(dataset=case['dataset'], seed=1, split='Base validation', role=role, method=name, **m))
        if case['mode'] == 'weighted_nckd':
            for name, m in case['comparators'].items():
                writer.writerow(dict(dataset=case['dataset'], seed=1, split='Base validation', role='fixed_comparator', method=name, **m))
            writer.writerow(dict(dataset=case['dataset'], seed=1, split='Base validation', role='historical_diagnostic', method='S1+M_logits', **case['historical_S1_plus_M']))
csv_bytes = f.getvalue().encode()
csv_path = report / 'all-metrics.csv'
if csv_path.exists():
    assert csv_path.read_bytes() == csv_bytes
else:
    csv_path.write_bytes(csv_bytes)

members = []
excluded = []
for item in receipt['files']:
    name = item['path']
    if name.endswith('.pth.tar-20'):
        excluded.append(item)
        continue
    p = unpacked / name
    assert sha(p) == item['sha256']
    members.append((p, name))
assert len(excluded) == 4
pathmap = {}
for case in read(w.parent / 'h1-prep-20260913/local-cases.json'):
    p = Path(case['historical_export'])
    for source in (p, p.with_name('logits.npz')):
        name = 'historical/' + case['dataset'] + '-seed1/' + source.name
        existing = [p for p, n in members if n == name]
        if existing:
            assert len(existing) == 1 and sha(existing[0]) == sha(source)
        else:
            members.append((source, name))
        pathmap[str(source)] = name
for name in ('preflight.py', 'preflight.json', 'start-record.json', 'monitor.py', 'collect_results.py', 'verify_backup.py', 'audit_results.py', 'independent-audit.json', 'independent-audit-run-1.log', 'inputs-after.json', 'collection-summary.json', 'package_report.py', 'package-report.log'):
    members.append((w / name, 'local/' + name))
for p in sorted((w / 'snapshots').glob('*.json')):
    members.append((p, 'local/snapshots/' + p.name))
rows = [{'path': name, 'bytes': p.stat().st_size, 'sha256': sha(p)} for p, name in members]
assert len({r['path'] for r in rows}) == len(rows)
manifest = {
    'files': rows,
    'full_backup_archive_sha256': receipt['archive_sha256'],
    'excluded_checkpoint_files': excluded,
    'historical_source_to_archive_path': pathmap,
    'remote_path_mapping': {'study': '/root/autodl-tmp/textconsistency/runs/h1-validation-20260913-efcd3db', 'preparation': '/root/autodl-tmp/textconsistency/setup-logs/h1-validation-20260913-efcd3db', 'launch': '/root/autodl-tmp/textconsistency/setup-logs/h1-gpu-start-20260913-efcd3db'},
    'note': 'Original files are byte-preserved. Paths map for reading only. The independent audit also requires the full model backup and its original historical-path mapping; no standalone training or rerun command is implied.',
}
raw = (json.dumps(manifest, indent=2) + '\n').encode()
archive = evidence / 'h1-gpu-lightweight-evidence-20260913.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for p, name in members:
        tar.add(p, arcname=name, recursive=False)
    m = tarfile.TarInfo('EVIDENCE_MANIFEST.json')
    m.size = len(raw)
    tar.addfile(m, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(rows) + 1
    assert tar.extractfile('EVIDENCE_MANIFEST.json').read() == raw
    for r in rows:
        b = tar.extractfile(r['path']).read()
        assert len(b) == r['bytes'] and hashlib.sha256(b).hexdigest() == r['sha256']
light = {'state': 'passed', 'archive': str(archive.relative_to(report)), 'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive), 'data_file_count': len(rows), 'manifest_file_count': 1, 'every_member_reopened_and_verified': True, 'excluded_model_files': len(excluded)}
(report / 'lightweight-verification.json').write_text(json.dumps(light, indent=2) + '\n')
summary = {'state': 'completed_and_backed_up', 'study_state': 'stopped', 'method_gate_passed': False, 'training_runs': 4, 'training_runs_all_passed': True, 'exports': 4, 'exports_all_passed': True, 'stage_count': 13, 'first_twelve_stages_passed': True, 'final_stage_exit_code': 2, 'final_stage_reason': 'All three predefined numerical guards failed; controlled stop, no retry.', 'original_input_file_count': len(after['files']), 'original_inputs_unchanged': True, 'independent_audit_passed': True, 'full_backup_file_count': verified['file_count'], 'full_backup_checkpoint_count': verified['checkpoint_file_count'], 'full_backup_archive_sha256': verified['archive_sha256'], 'gpu_compute_processes_after': [], 'server_power_unchanged': True, 'novel_or_hm': False, 'source_code_changed_this_gpu_turn': False}
(report / 'final-verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'lightweight': light, 'final': summary}, indent=2))
