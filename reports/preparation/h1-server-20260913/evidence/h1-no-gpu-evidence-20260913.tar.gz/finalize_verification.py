"""Assemble final preparation verdict only from completed local/server evidence."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess
p=argparse.ArgumentParser();p.add_argument('--server-evidence',required=True,type=Path);p.add_argument('--label',required=True);a=p.parse_args()
w=Path(__file__).resolve().parent;repo=w.parent/'h1-cpu-20260912/source';remote=a.server_evidence/'preparation'
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert commit.startswith(a.label)
manifest=read(w/('deployment-'+a.label)/'manifest.json');assert manifest['commit']==commit
ready=read(remote/'ready.json');status=read(remote/'status.json');plan=read(remote/'future-plan/plan.json')
assert ready['commit']==commit and status['commit']==commit and ready['state']==status['state']=='cpu_preparation_complete'
assert ready['source_archive_sha256']==manifest['archive_sha256'] and ready['operation_sha256']==manifest['operation_sha256']
assert ready['inputs_unchanged'] and ready['study_output_absent'] and ready['formal_training_runs']==0 and not ready['gpu_training_started']
labels=['masked-cpu-environment','full-tests','prepare-anchor-dtd','prepare-candidate-ucf101','prepare-candidate-dtd','prepare-candidate-fgvc_aircraft','plan-only']
assert [r['label'] for r in status['commands']]==labels and all(r['returncode']==0 for r in status['commands'])
for row in status['commands']:
 log=remote/Path(row['log']).name;assert sha(log)==row['log_sha256']
assert read(remote/'inputs-before.json')==read(remote/'inputs-after.json')
assert len(read(remote/'inputs-before.json'))==2516
assert plan['state']=='planned_not_executed' and len(plan['cases'])==4
kinds=[s['kind'] for s in plan['stages']];assert kinds==['train','export','anchor_audit']+['train','export','candidate_analysis']*3+['aggregate']
assert sha(remote/'future-plan/plan.json')==ready['plan_sha256']
for row in ready['prepared']:
 receipt=remote/Path(row['path']).parent.name/'prepared.json';assert sha(receipt)==row['sha256']
proofs={name:read(path) for name,path in {
 'local_preparation':w/'local-preparation-audit-5145115.json',
 'local_arithmetic':w/'analysis-verification.json',
 'local_plan':w/('local-plan-verification-'+a.label+'.json'),
 'no_cuda_refusal':w/('no-cuda-verification-'+a.label+'.json'),
 'server_preparation':w/'server-preparation-audit.json',
 'cross_machine':w/'cross-machine-verification.json',
 'download':a.server_evidence/'download-verification.json',
 'upload':w/'server-upload-verification.json'}.items()}
assert all(r['state']=='passed' for r in proofs.values())
assert not Path(read(Path(proofs['local_plan']['plan']))['output_root']).exists()
counts={}
for key,path in {'local':w/'task2-review-round1-full.log','server':remote/'full-tests.log'}.items():
 text=path.read_text();m=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+\nOK',text)
 assert m and int(m.group(1))==193
 counts[key]={'count':int(m.group(1)),'seconds':float(m.group(2)),'log_sha256':sha(path)}
for name,digest in manifest['operation_sha256'].items():assert sha(repo/name)==digest
changed=subprocess.check_output(['git','diff','--name-only','ce02dbe',commit,'--','train.py','trainers','datasets','clip','Dassl.pytorch'],cwd=repo,text=True);assert not changed.strip()
result={'state':'passed','scope':'H1 independent Base-validation tooling and no-GPU deployment/preparation only',
 'code_commit':commit,'training_source_sha256':'387ea6e46aa0fa6cba5109e64baab94a548b35c200a1945267d392bc35a36677',
 'training_source_unchanged':True,'source_archive_sha256':manifest['archive_sha256'],'operation_sha256':manifest['operation_sha256'],
 'full_tests':counts,'actual_cpu_preparations':{'local':4,'server':4},'unique_train_images':2000,'unique_val_images':500,
 'input_files_verified':2516,'inputs_unchanged':True,'cross_machine_sample_image_config_match':True,
 'server_environment':read(w/'server-environment-final.json'),'server_release':ready['release'],'server_preparation':manifest['preparation_dir'],
 'server_plan':ready['plan'],'server_plan_sha256':ready['plan_sha256'],'server_plan_identity_sha256':plan['plan_identity_sha256'],
 'future_study_output':ready['future_study_output'],'future_study_absent':True,'planned_stages':13,'future_training_cap':4,
 'future_training_order':['DTD full_kl anchor','UCF101 weighted_nckd','DTD weighted_nckd','FGVC Aircraft weighted_nckd'],
 'no_cuda_guard_verified':True,'formal_training_runs':0,'gpu_training_started':False,'h1_accuracy_available':False,
 'software_evidence':proofs,'server_command_summary':status['commands'],
 'review_verdict':'Task1/Task2 re-reviews and final whole-branch review passed; no blocking findings',
 'deferred_minor':'stage_validator Callable type annotation has2arguments; runtime/default/test calls correctly use3; fix when next touched',
 'limitations':['No real-data H1 training or CUDA export occurred','Anchor reproducibility and model improvement remain unverified','Known KL decomposition ablation is not a proven new algorithm','Base validation exploratory only; no Novel/HM or publication guarantee'],
 'publication':'Report/evidence ready for authorized GitHub commit and push; remote equality is recorded separately after publication'}
out=w/'final-verification.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('state','code_commit','full_tests','actual_cpu_preparations','planned_stages','formal_training_runs')},indent=2))
