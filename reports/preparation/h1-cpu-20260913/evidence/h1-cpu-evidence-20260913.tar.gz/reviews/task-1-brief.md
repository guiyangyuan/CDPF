## Task 1: Implement the single weighted non-target loss

Ownership: trainers/textconsistency_common.py (training_losses and any loss-local helper only) and a new tests/repro/test_kd_losses.py. Do not edit checkpoint loading or other files owned by task 2.

Add keyword-only kd_loss_mode='full_kl' to training_losses after existing contrastive_weight positional argument. The only other allowed value is 'weighted_nckd'. Keep the historical full-KL expression and operation order for valid default calls exactly unchanged. New mode is batch mean of (1-q_y)*T^2*KL(q_non_target||p_non_target), teacher q and weight detached, with the true class removed before conditional softmax. Compute teacher non-target mass stably, e.g. sum the non-target probabilities rather than subtract a rounded q_y from one. Do not add unweighted NCKD, DKD alpha/beta knobs, gates or logit normalization. Keep student CE, online teacher CE and negative entropy unchanged.

Reject unknown mode even with KD disabled, nonfinite/nonpositive temperature and invalid weights, and malformed active weighted-KD input (teacher absent, incompatible shape, fewer than two classes, invalid labels). Two-class weighted NCKD is correctly zero because there is one non-target class; this is supported. Preserve ordinary teacher-less baseline behavior in full_kl mode.

TDD: new tests must first fail due to missing behavior. Derive expectations independently using full KL minus its binary target/non-target KL, including value AND student gradient; check true-class KD gradient zero, teacher KD gradients absent but teacher CE gradients intact, non-target normalization, class permutation/batch-mean weighting, finite extreme-logit behavior, two-class zero, KD=0 behavior and invalid options. Compare default full KL and explicit full_kl values/gradients with frozen historical formula at exact equality. Preserve RED/GREEN command/output evidence outside tracked product files.

Use /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python, OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1. Tests under tests/repro use unittest discovery. No new dependencies. Commit only owned files, report exact commands, failures and passes. No subagents.

