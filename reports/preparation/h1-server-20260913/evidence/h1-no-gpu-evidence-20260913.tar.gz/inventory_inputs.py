from pathlib import Path
import hashlib,json

work=Path(__file__).resolve().parent; root=work.parent.parent
server_root='/root/autodl-tmp/textconsistency'
def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()
old_preps=root/'work/validation-probe-20260911/prepared-ce31832'
matches=json.loads((root/'work/validation-server-20260911-42527/input-match.json').read_text())
snapshot={'purpose':'read-only H1 seed1 deployment input inventory','cases':[],'files':[]}
files={}
for dataset in ('ucf101','dtd','fgvc_aircraft'):
    prep=json.loads((old_preps/(dataset+'-seed1')/'prepared.json').read_text())
    data=Path(prep['data_root']); remote=next(x['source'] for x in matches['matched'] if x['dataset']==dataset and x['seed']==1 and x['role']=='kd1')
    export=root/'work/validation-gpu-20260912-42527/unpacked/validation-probe-20260911-v1/exports'/f'{dataset}-seed1'/'export.json'
    case={'dataset':dataset,'data_root':str(data),'historical_config':prep['checkpoints']['kd1']['effective_config'],'historical_export':str(export),'remote_historical_config':remote['config'],'remote_historical_export':server_root+'/runs/validation-probe-20260911-v1/exports/'+dataset+'-seed1/export.json','sample_hashes':prep['sample_hashes'],'train_count':len(prep['samples']['train']),'val_count':len(prep['samples']['val'])}
    snapshot['cases'].append(case)
    pairs=[(Path(case['historical_config']),case['remote_historical_config']),(export,case['remote_historical_export']),(export.with_name('logits.npz'),str(Path(case['remote_historical_export']).with_name('logits.npz')))]
    pairs += [(Path(x['path']),server_root+'/data/'+str(Path(x['path']).relative_to(data))) for x in prep['source_metadata']]
    pairs += [(data/x['sample_id'],server_root+'/data/'+x['sample_id']) for split in ('train','val') for x in prep['samples'][split]]
    for local,remote_path in pairs:
        files[remote_path]={'local':str(local),'remote':remote_path,'bytes':local.stat().st_size,'sha256':sha(local)}
clip=root/'outputs/textConsistency-repro/clip/ViT-B-16.pt'
files[server_root+'/src/clip/ViT-B-16.pt']={'local':str(clip),'remote':server_root+'/src/clip/ViT-B-16.pt','bytes':clip.stat().st_size,'sha256':sha(clip)}
snapshot['files']=list(files.values())
(work/'local-input-inventory.json').write_text(json.dumps(snapshot,indent=2)+'\n')
script='''from pathlib import Path
import json,hashlib,platform,os,subprocess
expected=EXPECTED_INPUTS
results=[]
for item in expected:
 p=Path(item['remote']); size=p.stat().st_size
 with p.open('rb') as f: actual=hashlib.file_digest(f,'sha256').hexdigest()
 results.append({'path':str(p),'bytes':size,'sha256':actual,'matches':size==item['bytes'] and actual==item['sha256']})
print(json.dumps({'hostname':platform.node(),'cgroup_memory_max':Path('/sys/fs/cgroup/memory.max').read_text().strip(),'files':results,'all_match':all(x['matches'] for x in results)},indent=2))
'''.replace('EXPECTED_INPUTS',repr(snapshot['files']))
(work/'server_scout.py').write_text(script)
print(json.dumps({'files':len(files),'bytes':sum(x['bytes'] for x in files.values()),'cases':[{k:v for k,v in x.items() if k in ('dataset','train_count','val_count')} for x in snapshot['cases']]}))
