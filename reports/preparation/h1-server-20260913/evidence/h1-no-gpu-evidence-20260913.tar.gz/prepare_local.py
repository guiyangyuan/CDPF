"""Run four actual-data CPU preparations in independent processes, without training."""
from pathlib import Path
import argparse,json,os,subprocess,time

work=Path(__file__).resolve().parent; source=work.parent/'h1-cpu-20260912/source'
python=work.parent/'tc-venv/bin/python'
parser=argparse.ArgumentParser(); parser.add_argument('--output',required=True,type=Path)
args=parser.parse_args(); out=args.output.resolve()
if out.exists(): raise FileExistsError(out)
out.mkdir(parents=True)
env=dict(os.environ,PYTHONPATH=str(source)+':'+str(source/'Dassl.pytorch'),
    OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='')
cases=json.loads((work/'local-cases.json').read_text())
status={'state':'preparing','commands':[],'formal_training_runs':0,'gpu_training_started':False}
try:
    for case in cases:
        cmd=[str(python),str(source/'scripts/repro/h1_validation.py'),'prepare',
             '--source-root',str(source),'--data-root',case['data_root'],
             '--historical-export',case['historical_export'],'--historical-config',case['historical_config'],
             '--dataset',case['dataset'],'--mode',case['mode'],'--output-dir',str(out/case['key'])]
        start=time.time(); logfile=out/(case['key']+'.log')
        with logfile.open('w') as log:
            result=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
        status['commands'].append({'case':case['key'],'command':cmd,'returncode':result.returncode,'seconds':time.time()-start})
        (out/'execution.json').write_text(json.dumps(status,indent=2)+'\n')
        print(json.dumps(status['commands'][-1]),flush=True)
        if result.returncode: raise RuntimeError('CPU prepare failed: '+case['key'])
    status['state']='cpu_prepared'
except BaseException as exc:
    status['state']='failed';status['error']=type(exc).__name__+': '+str(exc);raise
finally:
    (out/'execution.json').write_text(json.dumps(status,indent=2)+'\n')
