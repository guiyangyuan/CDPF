"""Authenticate every downloaded CPU evidence member before extracting it."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,tarfile
p=argparse.ArgumentParser();p.add_argument('--download',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
r=json.loads((a.download/'server-evidence-receipt.json').read_text());archive=a.download/r['archive']
assert archive.parent.resolve()==a.download.resolve()
with archive.open('rb') as f: assert hashlib.file_digest(f,'sha256').hexdigest()==r['sha256']
assert archive.stat().st_size==r['bytes'] and r['formal_training_runs']==0 and r['gpu_training_started'] is False
expected={x['path']:x for x in r['files']};assert len(expected)==len(r['files'])
assert not a.output.exists()
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(expected) and {x.name for x in members}==set(expected)
 for member in members:
  name=PurePosixPath(member.name);assert member.isfile() and not name.is_absolute() and '..' not in name.parts
  raw=tar.extractfile(member).read();item=expected[member.name]
  assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
 a.output.mkdir();tar.extractall(a.output,filter='data')
for name,item in expected.items():
 path=a.output/name
 with path.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==item['sha256']
result={'state':'passed','commit':r['commit'],'files':len(expected),'archive_sha256':r['sha256'],'archive_bytes':r['bytes'],'all_members_verified_before_and_after_extract':True,'formal_training_runs':0,'gpu_training_started':False}
(a.output/'download-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
