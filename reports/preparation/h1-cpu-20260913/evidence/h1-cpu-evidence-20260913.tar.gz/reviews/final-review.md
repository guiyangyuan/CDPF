# Final whole-branch code review

## Review Summary

- Target: `5945102..696aa20` (10 changed files); reviewed HEAD is `696aa2018c872889153beb0ad65c0861db3ef099`.
- Recommendation: **REQUEST_CHANGES — not ready to merge until M-001 is resolved.**
- Findings: CRITICAL 0; HIGH 0; MEDIUM 1; LOW 0.

## Status Reason

The loss and checkpoint implementation meet the contract, and weighted sparse audits now fail closed. One remaining cross-layer temperature identity gap affects sparse full-KL audits carrying modern metadata.

## Inputs Reviewed

`docs/plans/2026-09-12-h1-cpu.md`, `docs/KD_LOSS_CONTROL.md`, supplied full diff, task reports, previous task-2 review, and `../final-verification.json`. Product-file SHA-256 values and HEAD were independently checked against that verification record and match.

## Change Scope

Reviewed all changes in `train.py`, `trainers/textconsistency_common.py`, `trainers/textconsistency_runtime.py`, `scripts/repro/summarize.py`, four changed test files, and the two design/scope documents. Followed the three validated trainers and initialization/load/evaluation call paths. The controller's untracked preparation report is outside this implementation review. No product or Git state was changed.

## Requirement Coverage

- **Covered:** exact historical full-KL expression/order and teacherless default; weighted conditional non-target KL with detached teacher mass/distribution; student and online teacher CE preserved; invalid options/input checks; two-class zero.
- **Covered:** config default and supported entry points; complete mode/temperature/effective-weight/weighting identity in runtime signature, manifest, checkpoint and metrics; checkpoint rejection before parameter load with source digest checks retained.
- **Partial:** cross-layer audit identity enforcement. Complete weighted protocols and sparse mode rejection are covered; available full-KL temperature fields can disagree under sparse protocols (M-001).
- **Covered:** CPU-only tests and archived real-logit checks; no new GPU queue, formal experiment, accuracy or novelty claim in the reviewed changes.

## Diagnostics and Verification

Relied on the matching final verification record: 152 tests passed, six configuration checks passed, 36 exact historical loss/gradient comparisons and 18 weighted chain-decomposition checks passed. Did not rerun broad suites. Ran one CPU-only, temporary-fixture proof for M-001; it accepted three aggregate rows despite the conflicting temperatures below.

## Findings

### Important: M-001 — Sparse full-KL audits ignore available temperature identity across records

- **Severity:** MEDIUM. **Confidence:** HIGH.
- **Locations:** `scripts/repro/summarize.py:168`, `scripts/repro/summarize.py:250`, `scripts/repro/summarize.py:256`.
- **Evidence:** Starting from `write_new_run(..., ('flat',), kd_loss_mode='full_kl')`, remove only protocol `kd_weight`, leaving `fixed_settings.kd_temp=2`. Change both manifest identity copies to temperature 9 and training config `KD_TEMP` to 7; leave every metric identity at temperature 2. `collect(root)` succeeds and returns three rows. The sparse path checks each manifest's internal canonical form and config mode, but never compares the available scalar identity to metrics/config/protocol. `read_metric` also discards the known protocol temperature when the weight is absent.
- **Impact:** Modern full-KL controls with inconsistent temperature provenance can be accepted as a matched experiment. The successful weighted-mode fix does not resolve this requested cross-layer identity invariant.
- **Repair:** Compare each available expected scalar independently, and compare present loss identities against available manifest/metric/config fields even for sparse full-KL protocols. Keep genuine legacy omission accepted as full KL; do not require new fields from legacy fixtures. Add this regression fixture alongside the existing sparse-mode cases.

Focused proof command, from the reviewed source directory:

```bash
PYTHONPATH=.:Dassl.pytorch:tests OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/bytedance/Documents/Codex/2026-09-08/https-github-com-zhengli97-awesome-prompt/work/tc-venv/bin/python - <<'PY'
import json, tempfile, yaml
from pathlib import Path
from repro.test_runner import write_new_run, module
with tempfile.TemporaryDirectory() as temp:
    root = write_new_run(Path(temp), ('flat',), kd_loss_mode='full_kl')
    path = root / 'protocol.json'
    data = json.loads(path.read_text()); data.pop('kd_weight')
    path.write_text(json.dumps(data))
    path = root / 'flat/seed1/run_manifest.json'
    data = json.loads(path.read_text())
    data['loss_identity']['temperature'] = 9.0
    data['model_signature']['loss_identity']['temperature'] = 9.0
    path.write_text(json.dumps(data))
    path = root / 'flat/seed1/effective_config.yaml'
    data = yaml.safe_load(path.read_text())
    data['TRAINER']['TEXTCONSISTENCY']['KD_TEMP'] = 7.0
    path.write_text(yaml.safe_dump(data))
    print(len(module('summarize').collect(root)))  # actual: 3; expected: reject
PY
```

### Minor

None.

## Open Questions

None.

## Positive Observations

The weighted loss uses deletion before conditional softmax and sums teacher non-target probability mass (`trainers/textconsistency_common.py:346`), avoiding subtraction cancellation while preserving the full-KL calculation. Checkpoint signature/provenance checks precede `load_state_dict` (`trainers/textconsistency_common.py:93`). Unknown modes and nonfinite coefficients are rejected before model assets load (`trainers/textconsistency_runtime.py:60`).

## Recommendation

**REQUEST_CHANGES.** Resolve the demonstrated sparse full-KL identity inconsistency, then perform focused regression verification. No further mathematical, trainer, checkpoint, or scope blocker was found.
