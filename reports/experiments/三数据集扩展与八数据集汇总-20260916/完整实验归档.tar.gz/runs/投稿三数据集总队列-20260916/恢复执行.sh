#!/usr/bin/env bash
set -Eeuo pipefail
queue_dir=/root/autodl-tmp/textconsistency/runs/投稿三数据集总队列-20260916
main_source=/root/autodl-tmp/textconsistency/releases/三数据集主方法-20260916-9bd4a7f
coco_source=/root/autodl-tmp/textconsistency/releases/三数据集扩展-20260916-9015b45
setup_dir=/root/autodl-tmp/textconsistency/setup-logs/三数据集扩展-20260916
python_bin=/root/autodl-tmp/textconsistency/.venv/bin/python
status_file="$queue_dir/状态.txt"
log_file="$queue_dir/恢复日志.txt"
exec 8>"$queue_dir/恢复队列锁"
flock -n 8 || { echo "恢复队列已运行"; exit 98; }
exec > >(tee -a "$log_file") 2>&1
trap 'exit_code=$?; printf "失败\t%s\t恢复队列退出码=%s\n" "$(date -Is)" "$exit_code" > "$status_file"; exit "$exit_code"' ERR
export PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=4
printf "运行中\t%s\t主方法-v2\n" "$(date -Is)" > "$status_file"
echo "[$(date -Is)] 从主方法v2恢复；Zero-shot已完成，不重复"
cd "$main_source"
export PYTHONPATH=.:Dassl.pytorch
"$python_bin" scripts/repro/运行三数据集主方法.py 执行 --plan-path "$setup_dir/主方法服务器计划-v2.json"
printf "运行中\t%s\t联合上下文基线\n" "$(date -Is)" > "$status_file"
echo "[$(date -Is)] 开始联合上下文基线"
cd "$coco_source"
export PYTHONPATH=.:Dassl.pytorch
"$python_bin" scripts/repro/运行三数据集联合上下文基线.py 执行阶段 --plan-path "$setup_dir/联合上下文基线服务器计划.json" --stage 新增三数据集
"$python_bin" scripts/repro/运行三数据集联合上下文基线.py 汇总 --plan-path "$setup_dir/联合上下文基线服务器计划.json"
printf "完成\t%s\n" "$(date -Is)" > "$status_file"
echo "[$(date -Is)] 三数据集恢复队列完成"
