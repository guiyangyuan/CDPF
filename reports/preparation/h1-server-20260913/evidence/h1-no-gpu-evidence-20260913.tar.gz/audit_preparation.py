"""Independent receipt check against the controller's pre-existing input inventory."""
from pathlib import Path
import argparse,copy,hashlib,json
import yaml

work=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(); parser.add_argument('--prepared-root',required=True,type=Path)
parser.add_argument('--output',required=True,type=Path); parser.add_argument('--implementation-commit',required=True)
args=parser.parse_args()
inventory=json.loads((work/'local-input-inventory.json').read_text())
by_path={x['remote']:x for x in inventory['files']}; results=[]; configs={}
cases=json.loads((work/'local-cases.json').read_text())
for case in cases:
    folder=args.prepared_root/case['key']; path=folder/'prepared.json'
    data=json.loads(path.read_text()); original=next(x for x in inventory['cases'] if x['dataset']==case['dataset'])
    assert data['status']=='prepared'
    assert data['seed']==1 and data['mode']==case['mode'] and data['dataset_key']==case['dataset']
    assert data['sample_hashes']==original['sample_hashes']
    assert data['source_sha256']=='387ea6e46aa0fa6cba5109e64baab94a548b35c200a1945267d392bc35a36677'
    for split in ('train','val'):
        actual=data['image_content'][split]['files']; samples=data['samples'][split]
        assert len(actual)==len(samples)==original[split+'_count']
        assert [x['sample_id'] for x in actual]==[x['sample_id'] for x in samples]
        for item in actual:
            expected=by_path['/root/autodl-tmp/textconsistency/data/'+item['sample_id']]
            assert item['size']==expected['bytes'] and item['sha256']==expected['sha256']
    config=copy.deepcopy(data['future_config'])
    saved=folder/'future_config.yaml'
    assert hashlib.sha256(saved.read_bytes()).hexdigest()==data['future_config_sha256']
    assert yaml.safe_load(saved.read_text())==config
    assert config['SEED']==1 and config['OPTIM']['MAX_EPOCH']==20
    assert config['TEST']['NO_TEST'] is True and config['TEST']['SPLIT']=='val'
    assert config['DATASET']['SUBSAMPLE_CLASSES']=='base' and config['DATASET']['NUM_SHOTS']==16
    assert config['TRAINER']['TEXTCONSISTENCY']['KD_LOSS_MODE']==case['mode']
    assert config['TRAINER']['TEXTCONSISTENCY']['KD_WEIGHT']==1.0
    assert config['TRAINER']['TEXTCONSISTENCY']['KD_TEMP']==2.0
    config['OUTPUT_DIR']='<output>';config['TRAINER']['TEXTCONSISTENCY']['KD_LOSS_MODE']='<mode>'
    configs[case['key']]=config
    results.append({'case':case['key'],'mode':data['mode'],'prepared_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'train':len(data['samples']['train']),'val':len(data['samples']['val']),
        'image_bytes_match_independent_inventory':True,'sample_hashes_match_historical':True,
        'future_test_split':'val','automatic_test_disabled':True,'changed_fields':data['config_derivation']['changed_fields']})
assert configs['anchor-dtd']==configs['candidate-dtd']
assert all(config['OPTIM']==configs['anchor-dtd']['OPTIM'] for config in configs.values())
result={'state':'passed','implementation_commit':args.implementation_commit,'cases':results,
    'dtd_pair_changes_only_mode_and_output':True,'optimizer_settings_equal_across_cases':True,
    'formal_training_runs':0,'gpu_training_started':False}
if args.output.exists(): raise FileExistsError(args.output)
args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'state':'passed','cases':len(results),'image_records_checked':sum(x['train']+x['val'] for x in results)}))
