from pathlib import Path
import hashlib,json
p=Path('/root/autodl-tmp/textconsistency/setup-logs/h1-validation-20260913-efcd3db-inbox')
expected=[{'name': 'collect_server_evidence.py', 'sha256': 'b69a3ed4ebce05d8a0484c3d0c24ba85b3c0ff3ca17e8090cd08da58414db18d', 'bytes': 1757}, {'name': 'deploy_and_prepare.py', 'sha256': 'b6840af7569585179892cd99b96deb506b95d6b711b4e3c463ac404dbb92bc2e', 'bytes': 6179}, {'name': 'h1-source-efcd3db.tar.gz', 'sha256': 'ab2cb0b7c0eb0338b0e151596ff96bc6bbcee60f7340c35dbea6fc824e28fab7', 'bytes': 22032400}, {'name': 'manifest.json', 'sha256': 'd676172f8b7681bcd3763bef9c0faf11ad4908ef011a74b0496e93b2fe09de60', 'bytes': 1013900}, {'name': 'upload-receipt.json', 'bytes': 809, 'sha256': 'a2ed53ccf7839093c34ae7be0bfbf6917c8da46a37f08ced2b7e4a2c7e44dc4f'}]
for x in expected:
 f=p/x["name"]
 assert f.stat().st_size==x["bytes"]
 with f.open("rb") as h: assert hashlib.file_digest(h,"sha256").hexdigest()==x["sha256"]
print(json.dumps({"state":"passed","files":expected},indent=2))
