"""One-shot CPU deployment verification for the already-reviewed 153953a release."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path('/root/autodl-tmp/textconsistency')
source = base/'releases/visual-adapter-pilot-20260913-153953a'
setup = base/'setup-logs/visual-adapter-pilot-20260913-153953a'
prepared = setup/'prepared/prepared.json'
plan = setup/'future-plan/plan.json'
output = base/'runs/visual-adapter-pilot-20260913-153953a'
python = str(base/'.venv/bin/python')
env = dict(os.environ, PYTHONPATH=f'{source}:{source}/Dassl.pytorch:{source}/tests',
           OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
status_path = setup/'cpu-status.json'
assert not status_path.exists() and not output.exists()
status = {'state': 'running_cpu_preparation', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source': str(source), 'gpu_training_started': False, 'stages': []}

def save():
    temp = status_path.with_suffix('.tmp')
    temp.write_text(json.dumps(status, indent=2)+'\n'); temp.replace(status_path)

def run(name, argv, *, timeout=300, expected=0):
    log = setup/(name+'.log')
    stage = {'name': name, 'argv': argv, 'log': str(log), 'state': 'running'}
    status['stages'].append(stage); save()
    started = time.monotonic()
    with log.open('x') as handle:
        completed = subprocess.run(argv, cwd=source, env=env, stdout=handle, stderr=subprocess.STDOUT, timeout=timeout)
    stage.update(returncode=completed.returncode, seconds=time.monotonic()-started)
    if completed.returncode != expected:
        stage['state'] = 'failed'; save()
        raise RuntimeError(f'{name} exited {completed.returncode}, expected {expected}; see {log}')
    stage['state'] = 'passed'; save(); print(name+' passed', flush=True)

try:
    save()
    environment_code = '''import sys,torch,torchvision,platform,json,shutil
from pathlib import Path
assert not torch.cuda.is_available(), 'Expected no-card preparation; stop if instance mode differs'
v={'hostname':platform.node(),'python':sys.version,'executable':sys.executable,'torch':torch.__version__,
'torchvision':torchvision.__version__,'cuda_runtime':torch.version.cuda,'cuda_available':torch.cuda.is_available(),
'memory_limit':Path('/sys/fs/cgroup/memory.max').read_text().strip(),'data_disk_free':shutil.disk_usage('/root/autodl-tmp').free}
Path(sys.argv[1]).write_text(json.dumps(v,indent=2)+'\\n')
print(json.dumps(v,indent=2))'''
    run('environment', [python, '-c', environment_code, str(setup/'environment.json')])
    run('cpu-tests', [python, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], timeout=600)
    assert 'Ran 234 tests' in (setup/'cpu-tests.log').read_text() and '\nOK\n' in (setup/'cpu-tests.log').read_text()
    run('prepare', [python, 'scripts/repro/visual_adapter_validation.py', 'prepare', '--data-root', str(base/'data'),
                    '--clip-path', str(base/'assets/ViT-B-16.pt'), '--output-dir', str(prepared.parent)])
    run('plan', [python, 'scripts/repro/visual_adapter_study.py', 'plan', '--prepared', str(prepared),
                '--plan-dir', str(plan.parent), '--output-root', str(output), '--python', python])
    run('no-cuda-rejection', [python, 'scripts/repro/visual_adapter_study.py', 'run', '--plan', str(plan)], expected=1)
    assert 'CUDA is required; no output directory or child process was created' in (setup/'no-cuda-rejection.log').read_text()
    assert not output.exists()
    run('portable-transform', [python, str(setup/'portable_transform.py'), '--source', str(source), '--prepared', str(prepared),
                               '--output', str(setup/'portable-transform.json')])
    p = json.loads(prepared.read_text()); q = json.loads(plan.read_text())
    ready = {'state': 'server_cpu_prepared_awaiting_gpu', 'source_commit': '153953a32a74e7dbf1c8784465b8b41cc769a5e8',
             'source': str(source), 'setup': str(setup), 'prepared': str(prepared), 'plan': str(plan), 'future_output': str(output),
             'training_source_sha256': p['source_sha256'], 'prepared_identity_sha256': p['prepared_identity_sha256'],
             'plan_identity_sha256': q['plan_identity_sha256'], 'plan_sha256': hashlib.sha256(plan.read_bytes()).hexdigest(),
             'input_count': len(p['input_files']), 'sample_counts': {key:len(value) for key,value in p['samples'].items()},
             'cpu_tests': 234, 'no_cuda_rejection_passed': True, 'output_exists': output.exists(),
             'real_model_loaded': False, 'gpu_training_started': False, 'accuracy_results': False,
             'cross_machine_verification': 'pending_local_comparison',
             'gpu_command': [python, 'scripts/repro/visual_adapter_study.py', 'run', '--plan', str(plan)]}
    (setup/'server-ready.json').write_text(json.dumps(ready, indent=2)+'\n')
    status['state'] = 'server_cpu_prepared_awaiting_local_comparison'
except BaseException as exc:
    status['state'] = 'failed'; status['error'] = f'{type(exc).__name__}: {exc}'; raise
finally:
    status['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat(); save()
