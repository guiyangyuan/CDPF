# Task 1 review

## Spec Compliance

**Verdict: FAIL**

- **[P1] `scripts/repro/h1_validation.py:1049` — export output protection omits authenticated source/data inputs.** `export_case` checks the fresh output only against `prepared_path` and `model_dir` before creating it. A new path below the prepared receipt's `source_root` or `data_root` is therefore accepted and can receive `failure.json`, `logits.npz`, and `export.json`, contrary to the global requirement that outputs be fresh and disjoint from inputs. The post-export `load_prepared` does not cure this: these new non-source files need not change the source digest or any sampled-image binding. A focused path-only reproducer confirmed that `data_root / "export"` is accepted. Fix by extracting the receipt's protected paths before creating the output, rejecting containment against at least `source_root`, `data_root`, the prepared artifact directory, and model directory, then repeating the check using the fully validated prepared receipt before model/checkpoint work.

All other scoped requirements are supported by the packaged diff and evidence: fixed seed/mode/source/loss/config identities, authenticated historical snapshot/export/NPZ/config bindings, cache-free reconstruction, exact cache-free/cache train and val equality, CPU prepare without model/optimizer/CUDA construction, strict epoch-20 checkpoint reload, sequential Base-val `S`/`T`/normalized masked-mean `M`/alpha-.5 ensemble export, relative rows/classes, and full `load_export` revalidation. The four real CPU prepares passed without training; actual cache equality was exact for DTD 384/96, UCF101 816/204, and FGVC Aircraft 800/200 train/val rows.

## Task Quality

**Verdict: FAIL**

- **[P1] `tests/repro/test_h1_validation.py:279` and `tests/repro/test_h1_validation.py:354` — freshness tests cover an existing export directory and no-CUDA failure recording, but not a fresh output nested under authenticated source/data inputs.** Add focused negative cases that assert rejection without creating anything below either input tree. This would have caught the line 1049 containment gap.

The remaining implementation quality is acceptable for the scope. The 1,128-line module is large but split into narrow validation/export functions, reuses the historical probe and analysis helpers for source, dataset, transform, strict-load, and historical-export semantics, and does not require cosmetic restructuring. Supplied validation passed 15/15 focused tests and 168/168 full tests.
