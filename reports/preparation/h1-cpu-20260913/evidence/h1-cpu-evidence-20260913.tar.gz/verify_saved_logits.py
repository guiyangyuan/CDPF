"""Independent CPU-only check of new loss on authenticated historical logits.

No model loading, optimizer, or new accuracy experiment. Run after implementation.
"""
import ast
import hashlib
import inspect
import json
from pathlib import Path
import sys

import numpy as np
import torch
from torch.nn import functional as F

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
REPO = WORK / 'source'
sys.path[:0] = [str(REPO), str(REPO / 'Dassl.pytorch')]
from trainers.textconsistency_common import training_losses
from trainers.textconsistency_runtime import source_digest


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    output = WORK / 'saved-logit-verification.json'
    if output.exists():
        raise FileExistsError(output)
    torch.set_num_threads(1)
    receipt = read(ROOT / 'work/validation-gpu-20260912-42527/backup-receipt.json')
    unpacked = ROOT / 'work/validation-gpu-20260912-42527/unpacked'
    before = {}
    for item in receipt['files']:
        path = unpacked / item['path']
        before[str(path)] = sha(path)
        assert before[str(path)] == item['sha256']
    diagnosis_path = ROOT / 'work/kd-diagnosis-20260912/results/diagnosis.json'
    diagnosis = read(diagnosis_path)
    functions = {}
    for location, entry in diagnosis['sources'].items():
        path = Path(location) / 'trainers/textconsistency_common.py'
        before[str(path)] = sha(path)
        assert before[str(path)] == entry['loss_file_sha256']
        node = next(node for node in ast.parse(path.read_text()).body
                    if isinstance(node, ast.FunctionDef) and node.name == 'training_losses')
        namespace = {'F': F, 'torch': torch}
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), 'exec'), namespace)
        functions[location] = namespace['training_losses']
    code_sha = source_digest()
    checks = []
    samples = 0
    for export in sorted(unpacked.glob('*/exports/*/export.json')):
        metadata = read(export)
        arrays_path = export.parent / 'logits.npz'
        assert sha(arrays_path) == metadata['npz_sha256']
        preparation = ROOT / 'work/validation-probe-20260911/prepared-ce31832' / export.parent.name / 'prepared.json'
        historical = functions[read(preparation)['source_root']]
        with np.load(arrays_path, allow_pickle=False) as arrays:
            assert np.array_equal(arrays['T0'], arrays['T1'])
            labels = torch.tensor(arrays['labels'], dtype=torch.long)
            samples += len(labels)
            for branch in ('S0', 'S1'):
                for dtype in (torch.float32, torch.float64):
                    z = torch.tensor(arrays[branch], dtype=dtype, requires_grad=True)
                    t = torch.tensor(arrays['T0'], dtype=dtype, requires_grad=True)
                    old, old_parts = historical(z, t, labels, None, 1., 2., 1., 0.)
                    new, new_parts = training_losses(z, t, labels, None, 1., 2., 1., 0.)
                    explicit, _ = training_losses(z, t, labels, None, 1., 2., 1., 0., kd_loss_mode='full_kl')
                    assert torch.equal(old, new) and torch.equal(new, explicit)
                    assert all(torch.equal(old_parts[k], new_parts[k]) for k in old_parts)
                    old_grad = torch.autograd.grad(old, (z, t), retain_graph=True)
                    new_grad = torch.autograd.grad(new, (z, t), retain_graph=True)
                    assert all(torch.equal(a, b) for a, b in zip(old_grad, new_grad))
                    item = {'case': export.parent.name, 'branch': branch, 'dtype': str(dtype),
                            'default_full_kl_loss_and_gradients_exact': True, 'records': len(labels)}
                    if dtype == torch.float64:
                        _, parts = training_losses(z, t, labels, None, 1., 2., 1., 0., kd_loss_mode='weighted_nckd')
                        actual = parts['loss_kd']
                        lp = F.log_softmax(z / 2., dim=-1)
                        lq = F.log_softmax(t.detach() / 2., dim=-1)
                        rest = torch.arange(z.shape[1])[None, :] != labels[:, None]
                        bp = torch.stack((lp.gather(1, labels[:, None]).squeeze(1),
                                          lp.masked_fill(~rest, -torch.inf).logsumexp(1)), dim=1)
                        bq = torch.stack((lq.gather(1, labels[:, None]).squeeze(1),
                                          lq.masked_fill(~rest, -torch.inf).logsumexp(1)), dim=1)
                        expected = 4. * (F.kl_div(lp, lq.exp(), reduction='batchmean')
                                         - F.kl_div(bp, bq.exp(), reduction='batchmean'))
                        gradient, teacher_gradient = torch.autograd.grad(actual, (z, t), retain_graph=True, allow_unused=True)
                        expected_gradient = torch.autograd.grad(expected, z)[0]
                        value_error = float((actual - expected).detach().abs())
                        gradient_error = float((gradient - expected_gradient).abs().max())
                        target_error = float(gradient.gather(1, labels[:, None]).abs().max())
                        assert value_error < 1e-12 and gradient_error < 1e-12 and target_error == 0
                        assert teacher_gradient is None
                        item.update(weighted_kl_chain_value_error=value_error,
                                    weighted_kl_chain_gradient_error=gradient_error,
                                    target_kd_gradient_max=target_error, teacher_kd_gradient_absent=True)
                    checks.append(item)
    assert samples == 1500 and len(checks) == 36
    assert all(sha(Path(path)) == digest for path, digest in before.items())
    assert source_digest() == code_sha
    function_sha = hashlib.sha256(inspect.getsource(training_losses).encode()).hexdigest()
    result = {'state': 'passed', 'source_sha256': code_sha, 'training_loss_function_sha256': function_sha,
              'records': samples, 'cases': 9,
              'default_exact_checks': 36, 'weighted_chain_checks': 18, 'checks': checks,
              'max_weighted_value_error': max(c.get('weighted_kl_chain_value_error', 0) for c in checks),
              'max_weighted_gradient_error': max(c.get('weighted_kl_chain_gradient_error', 0) for c in checks),
              'inputs_sha256': before, 'all_inputs_unchanged': True,
              'script_sha256': sha(Path(__file__)), 'model_loading': False, 'optimizer_steps': 0,
              'formal_training_runs': 0, 'new_accuracy_results': False}
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('checks', 'inputs_sha256')}, indent=2))


if __name__ == '__main__':
    main()
