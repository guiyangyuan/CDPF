#!/usr/bin/env bash
set -euo pipefail
root_dir=/root/autodl-tmp/textconsistency
prep_dir="$root_dir/preparation/剩余两数据集-20260917-03cc19f"
status_path="$root_dir/runs/投稿剩余两数据集联合上下文-20260917/剩余两数据集/执行状态.json"
summary_log="$prep_dir/实验完成后归档日志.txt"
recovery_pid=8931
while kill -0 "$recovery_pid" 2>/dev/null; do sleep 30; done
python - "$status_path" <<'PY'
import json,sys
p=sys.argv[1]; d=json.load(open(p))
assert d['状态']=='完成', d
assert d['已完成命令']==d['总命令']==18, d
PY
source_dir="$root_dir/releases/投稿标准基线-20260916-fc59a83"
PYTHONPATH="$source_dir:$source_dir/Dassl.pytorch" "$root_dir/.venv/bin/python" -B "$source_dir/scripts/repro/运行三数据集联合上下文基线.py" 汇总 --plan-path "$prep_dir/服务器核验/联合上下文剩余两数据集计划.json" > "$summary_log" 2>&1
archive="$root_dir/剩余两数据集完整实验归档-20260917.tar.gz"
tar -czf "$archive" -C "$root_dir" \
  "runs/投稿剩余两数据集零样本-20260917" \
  "runs/投稿剩余两数据集主方法-20260917" \
  "runs/投稿剩余两数据集联合上下文-20260917" \
  "preparation/剩余两数据集-20260917-03cc19f"
sha256sum "$archive" > "$prep_dir/完整归档SHA256.txt"
stat -c '%s bytes %n' "$archive" >> "$prep_dir/完整归档SHA256.txt"
