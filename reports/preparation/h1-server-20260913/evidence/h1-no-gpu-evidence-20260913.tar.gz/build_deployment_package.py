"""Build a fresh archive/manifest from a named committed tree; no remote action."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess
w=Path(__file__).resolve().parent;repo=w.parent/'h1-cpu-20260912/source'
p=argparse.ArgumentParser();p.add_argument('--commit',required=True);a=p.parse_args()
commit=subprocess.check_output(['git','rev-parse',a.commit+'^{commit}'],cwd=repo,text=True).strip()
package=w/('deployment-'+commit[:7]);assert not package.exists();package.mkdir()
archive=package/('h1-source-'+commit[:7]+'.tar.gz')
subprocess.run(['git','archive','--format=tar.gz','--output='+str(archive),commit],cwd=repo,check=True)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
operations={}
for name in ('train.py','scripts/repro/h1_validation.py','scripts/repro/h1_study.py','scripts/repro/h1_analysis.py'):
 raw=subprocess.check_output(['git','show',commit+':'+name],cwd=repo)
 assert hashlib.sha256(raw).hexdigest()==sha(repo/name)
 operations[name]=hashlib.sha256(raw).hexdigest()
for name in ('deploy_and_prepare.py','collect_server_evidence.py'):shutil.copy2(w/name,package/name)
base='/root/autodl-tmp/textconsistency';tag='h1-validation-20260913-'+commit[:7]
manifest={'commit':commit,'archive':archive.name,'archive_sha256':sha(archive),
 'release_dir':base+'/releases/'+tag,'preparation_dir':base+'/setup-logs/'+tag,
 'study_output':base+'/runs/'+tag,'data_root':base+'/data','python':base+'/.venv/bin/python',
 'clip_path':base+'/src/clip/ViT-B-16.pt','operation_sha256':operations,
 'expected_inputs':json.loads((w/'local-input-inventory.json').read_text())['files'],
 'cases':json.loads((w/'remote-cases.json').read_text())}
(package/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
receipt={'commit':commit,'remote_inbox':base+'/setup-logs/'+tag+'-inbox',
 'files':[{'name':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(package.iterdir()) if p.is_file()]}
(package/'upload-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
